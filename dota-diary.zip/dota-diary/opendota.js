// ===================================================
// Загрузка подробных данных матча из OpenDota (на сервере)
//
// Для разбора нам нужно больше данных, чем в списке матчей:
// предметы, тайминги покупок, сравнение с другими игроками на этом герое
// и т.д. Всё это есть в полной информации о матче: /api/matches/<номер>.
//
// Почему грузим на сервере, а не берём то, что прислал браузер?
// Браузеру нельзя доверять: кто угодно мог бы прислать выдуманные цифры.
// ===================================================

const API = 'https://api.opendota.com/api';

// ===== Справочники (герои и предметы) =====

// Загружаем один раз и держим в памяти, пока сервер работает
let heroNames = null; // { 1: "Anti-Mage", ... }
let heroRoles = null; // { 1: ["Carry", "Escape", "Nuker"], ... }
let items = null;     // { 1: { name: "Blink Dagger", cost: 2250 }, ... }

// Роли героев по-русски (так их понятнее читать и ИИ, и нам)
const ROLE_NAMES = {
  Carry: 'керри',
  Support: 'саппорт',
  Nuker: 'нюкер',
  Disabler: 'контроль',
  Jungler: 'лесник',
  Durable: 'танк',
  Escape: 'мобильность',
  Pusher: 'пушер',
  Initiator: 'инициатор',
};

// Ситуативные предметы (ключи из справочника OpenDota).
// Названия к ним подставятся точные, из того же справочника.
const SITUATIONAL_ITEMS = [
  'black_king_bar', 'sphere', 'lotus_orb', 'force_staff', 'glimmer_cape', 'cyclone',
  'ghost', 'aeon_disk', 'blade_mail', 'pipe', 'crimson_guard', 'spirit_vessel',
  'mage_slayer', 'heavens_halberd', 'sheepstick', 'orchid', 'bloodthorn', 'nullifier',
  'silver_edge', 'monkey_king_bar', 'abyssal_blade', 'shivas_guard', 'assault',
  'manta', 'satanic', 'butterfly', 'diffusal_blade', 'solar_crest', 'hurricane_pike',
  'eternal_shroud', 'wind_waker', 'gungir', 'disperser', 'harpoon', 'blink',
  'ward_sentry', 'dust', 'gem',
];

// Позиции 1–5
const POSITION_NAMES = {
  1: 'поз. 1, керри',
  2: 'поз. 2, мидер',
  3: 'поз. 3, оффлейнер',
  4: 'поз. 4, четвёрка',
  5: 'поз. 5, пятёрка',
};

async function getJson(url) {
  const response = await fetch(url);
  if (!response.ok) throw new Error(`OpenDota ответил ошибкой ${response.status}`);
  return response.json();
}

async function loadConstants() {
  if (heroNames && items) return;

  // heroStats — в отличие от /heroes, тут есть ещё и роли героев
  const [heroList, itemList] = await Promise.all([
    getJson(`${API}/heroStats`),
    getJson(`${API}/constants/items`),
  ]);

  heroNames = {};
  heroRoles = {};
  for (const hero of heroList) {
    heroNames[hero.id] = hero.localized_name;
    heroRoles[hero.id] = hero.roles || [];
  }

  // constants/items выглядит так: { "blink": { id: 1, dname: "Blink Dagger", cost: 2250 }, ... }
  // Нам удобнее искать по номеру (id) и по ключу ("blink"), поэтому делаем два способа доступа.
  items = { byId: {}, byKey: {} };
  for (const [key, item] of Object.entries(itemList)) {
    const info = {
      key, // короткое имя, например "black_king_bar" — по нему сайт узнаёт сленг ("БКБ")
      name: item.dname || key,
      cost: item.cost || 0,
      // img — "хвост" адреса картинки, полный адрес соберёт браузер
      img: item.img || '',
    };
    items.byKey[key] = info;
    if (item.id) items.byId[item.id] = info;
  }
}

function heroName(id) {
  return heroNames[id] || `герой #${id}`;
}

function itemName(id) {
  if (!id) return null; // 0 = пустой слот
  return items.byId[id]?.name || `предмет #${id}`;
}

// ===== Оценка позиций 1–5 =====
// OpenDota не говорит прямо, кто какой позиции. Но мы знаем:
//   - lane_role: на какой линии стоял герой (1 — лёгкая, 2 — мид, 3 — сложная, 4 — лес);
//   - net_worth: сколько у героя было золота в конце.
// На каждой линии самый богатый — кор (1, 2 или 3), остальные — саппорты (4 и 5).
// Это ОЦЕНКА: бывают необычные игры, где она ошибётся.
function estimatePositions(team) {
  const positions = new Map(); // Map — как объект, но ключом может быть что угодно (здесь — игрок)

  // Сортируем по золоту: самые богатые первыми
  const byGold = [...team].sort((a, b) => (b.net_worth || 0) - (a.net_worth || 0));
  const hasLanes = team.every((p) => p.lane_role);

  if (hasLanes) {
    // Самый богатый на миде — поз. 2, на лёгкой — поз. 1, на сложной — поз. 3
    const coreForLane = { 2: 2, 1: 1, 3: 3 };
    for (const [lane, pos] of Object.entries(coreForLane)) {
      const richest = byGold.find((p) => !p.is_roaming && String(p.lane_role) === lane && !positions.has(p));
      if (richest) positions.set(richest, pos);
    }
  }

  // Остальным раздаём свободные позиции по убыванию золота
  const free = [1, 2, 3, 4, 5].filter((pos) => ![...positions.values()].includes(pos));
  for (const p of byGold) {
    if (!positions.has(p)) positions.set(p, free.shift());
  }
  return positions;
}

// Одна строка про героя для ИИ:
// "Axe — поз. 3, оффлейнер; 5/7/12, нетворс 15 000; роли героя: инициатор, танк"
function describePlayer(p, position, isMe) {
  const roles = (heroRoles[p.hero_id] || []).map((r) => ROLE_NAMES[r] || r).join(', ');
  const parts = [
    `${heroName(p.hero_id)} — ${POSITION_NAMES[position] || 'позиция неизвестна'}${isMe ? ' (ЭТО ИГРОК)' : ''}`,
    `${p.kills}/${p.deaths}/${p.assists}`,
  ];
  if (typeof p.net_worth === 'number') parts.push(`нетворс ${p.net_worth.toLocaleString('ru-RU')}`);
  if (typeof p.gold_per_min === 'number') parts.push(`GPM ${p.gold_per_min}`);
  if (roles) parts.push(`роли героя: ${roles}`);
  return parts.join('; ');
}

// Секунды -> "мм:сс"
function formatTime(seconds) {
  const sign = seconds < 0 ? '-' : '';
  const s = Math.abs(seconds);
  return `${sign}${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
}

// ===== Главная функция =====

// Возвращает объект с данными игрока в этом матче (всё, что нужно ИИ)
async function getMatchSummary(matchId, accountId) {
  await loadConstants();
  const match = await getJson(`${API}/matches/${matchId}`);

  if (!Array.isArray(match.players)) {
    throw new Error('OpenDota не отдал данные игроков этого матча');
  }

  // Ищем нашего игрока среди 10 участников
  const player = match.players.find((p) => String(p.account_id) === String(accountId));
  if (!player) {
    throw new Error('Игрок не найден в этом матче');
  }

  const isRadiant = player.player_slot < 128;
  const win = isRadiant === match.radiant_win;

  // Делим игроков на команды и оцениваем позиции в каждой
  const myTeam = match.players.filter((p) => (p.player_slot < 128) === isRadiant);
  const enemyTeam = match.players.filter((p) => (p.player_slot < 128) !== isRadiant);
  const myPositions = estimatePositions(myTeam);
  const enemyPositions = estimatePositions(enemyTeam);

  // Сортируем по позиции (1, 2, 3, 4, 5) и превращаем в строки для ИИ
  const describeTeam = (team, positions) =>
    [...team]
      .sort((a, b) => positions.get(a) - positions.get(b))
      .map((p) => describePlayer(p, positions.get(p), p === player));

  const allies = describeTeam(myTeam, myPositions);
  const enemies = describeTeam(enemyTeam, enemyPositions);
  const myPosition = myPositions.get(player);

  // Против кого стоял на линии. Лёгкая линия одной команды = сложная линия другой.
  const oppositeLane = { 1: 3, 2: 2, 3: 1 };
  const laneOpponents = player.lane_role && !player.is_roaming && oppositeLane[player.lane_role]
    ? enemyTeam
        .filter((p) => !p.is_roaming && p.lane_role === oppositeLane[player.lane_role])
        .map((p) => `${heroName(p.hero_id)} (${POSITION_NAMES[enemyPositions.get(p)]})`)
    : [];

  // Итоговые предметы (6 слотов). filter(Boolean) убирает пустые слоты.
  const finalItems = [0, 1, 2, 3, 4, 5].map((i) => itemName(player[`item_${i}`])).filter(Boolean);

  // Тайминги дорогих покупок (от 1800 золота) — по ним видно, как шёл фарм.
  // purchase_log есть только у "разобранных" (parsed) матчей.
  const keyPurchases = [];
  if (Array.isArray(player.purchase_log)) {
    const seen = new Set(); // Set — набор без повторов, чтобы не писать предмет дважды
    for (const p of player.purchase_log) {
      const info = items.byKey[p.key];
      if (info && info.cost >= 1800 && !seen.has(p.key)) {
        seen.add(p.key);
        keyPurchases.push(`${info.name} — ${formatTime(p.time)}`);
      }
    }
  }

  // Все предметы, которые были у кого-то в этом матче (без повторов).
  // Даём ИИ точные названия, чтобы он не коверкал их.
  const matchItems = new Set();
  for (const p of match.players) {
    for (const slot of ['item_0', 'item_1', 'item_2', 'item_3', 'item_4', 'item_5', 'item_neutral']) {
      const name = itemName(p[slot]);
      if (name) matchItems.add(name);
    }
  }

  // Частые ситуативки — ИИ может советовать их, зная точные названия
  const situationalItems = SITUATIONAL_ITEMS
    .map((key) => items.byKey[key]?.name)
    .filter(Boolean);

  // Сравнение с другими игроками на этом герое.
  // pct = 0.3 значит "лучше, чем 30% игроков на этом герое".
  const benchmarkNames = {
    gold_per_min: 'Золото в минуту',
    xp_per_min: 'Опыт в минуту',
    kills_per_min: 'Убийства в минуту',
    last_hits_per_min: 'Ластхиты в минуту',
    hero_damage_per_min: 'Урон по героям в минуту',
    tower_damage: 'Урон по строениям',
    hero_healing_per_min: 'Лечение в минуту',
  };
  const benchmarks = [];
  if (player.benchmarks) {
    for (const [key, label] of Object.entries(benchmarkNames)) {
      const b = player.benchmarks[key];
      if (b && typeof b.pct === 'number') {
        benchmarks.push(`${label}: лучше, чем у ${Math.round(b.pct * 100)}% игроков на этом герое`);
      }
    }
  }

  const laneRoles = { 1: 'лёгкая линия (керри)', 2: 'мид', 3: 'сложная линия (оффлейн)', 4: 'лес' };

  return {
    matchId,
    hero: heroName(player.hero_id),
    win,
    durationMin: Math.round(match.duration / 60),
    lane: player.is_roaming ? 'роум (бегал по карте)' : laneRoles[player.lane_role] || 'неизвестно',
    position: POSITION_NAMES[myPosition],
    laneOpponents,
    kills: player.kills,
    deaths: player.deaths,
    assists: player.assists,
    gpm: player.gold_per_min,
    xpm: player.xp_per_min,
    lastHits: player.last_hits,
    denies: player.denies,
    // lh_t — ластхиты по минутам. lh_t[10] — сколько было на 10-й минуте.
    lastHitsAt10: Array.isArray(player.lh_t) ? player.lh_t[10] : undefined,
    netWorth: player.net_worth,
    heroDamage: player.hero_damage,
    towerDamage: player.tower_damage,
    heroHealing: player.hero_healing,
    laneEfficiency: player.lane_efficiency_pct,
    teamfight: typeof player.teamfight_participation === 'number'
      ? Math.round(player.teamfight_participation * 100)
      : undefined,
    observers: player.obs_placed,
    sentries: player.sen_placed,
    finalItems,
    keyPurchases,
    matchItems: [...matchItems], // [...набор] — превращаем Set обратно в обычный список
    situationalItems,
    benchmarks,
    allies,
    enemies,
    // "Разобран" ли матч: у разобранных есть подробности (покупки, ластхиты по минутам)
    parsed: Array.isArray(player.purchase_log),
  };
}

// Компактный справочник предметов для браузера: { id: { name, img } }.
// Полный справочник OpenDota весит несколько мегабайт — браузеру столько не нужно.
async function getItemsLite() {
  await loadConstants();
  const lite = {};
  for (const [id, info] of Object.entries(items.byId)) {
    lite[id] = { key: info.key, name: info.name, img: info.img };
  }
  return lite;
}

module.exports = { getMatchSummary, getItemsLite };
