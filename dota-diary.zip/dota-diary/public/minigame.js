// ===================================================
// Пасхалка в подвале: Ластхит-тренажёр
//
// Правила как в Доте: союзные крипы бьют вражеского крипа,
// а ты должен нанести ПОСЛЕДНИЙ удар — тогда золото твоё.
// У удара есть замах (attack point): от клика до урона проходит время,
// за которое союзники тоже успевают ударить. Это и есть вся сложность.
// ===================================================

(function () {
  const $ = (id) => document.getElementById(id);

  const openBtn = $('lh-open');
  const game = $('lh-game');
  const creepBtn = $('lh-creep');
  const hpFill = $('lh-hp-fill');
  const hpText = $('lh-hp-text');
  const startBtn = $('lh-start');
  const hardBox = $('lh-hard');
  const msg = $('lh-msg');
  const countEl = $('lh-count');
  const scoreEl = $('lh-score');
  const goldEl = $('lh-gold');
  const bestEl = $('lh-best');
  const floatLayer = $('lh-floats');
  if (!openBtn || !game) return;

  // ===== Настройки игры =====
  const CREEPS_PER_ROUND = 10;
  const CREEP_HP = 420;       // поменьше, чем в игре, чтобы раунд не тянулся
  const MY_DAMAGE = [52, 58];       // наш урон: случайно от 52 до 58
  const ALLY_DAMAGE = [20, 36];     // урон союзных крипов за удар
  const ALLY_DELAY = [350, 700];     // пауза между ударами союзников, мс
  const ATTACK_POINT = 300;         // замах нашего удара, мс
  const ATTACK_COOLDOWN = 700;      // через сколько можно ударить снова, мс

  // ===== Состояние =====
  let playing = false;
  let creepIndex = 0;   // какой по счёту крип
  let hp = CREEP_HP;
  let score = 0;
  let gold = 0;
  let alive = false;    // жив ли текущий крип
  let swinging = false; // идёт ли замах
  let allyTimer = null;

  const rand = (min, max) => Math.floor(min + Math.random() * (max - min + 1));

  // Рекорд хранится в памяти браузера
  function getBest() {
    try {
      return Number(localStorage.getItem('lhBest')) || 0;
    } catch {
      return 0;
    }
  }
  function setBest(value) {
    try {
      localStorage.setItem('lhBest', String(value));
    } catch {
      // не страшно
    }
  }

  // ===== Отрисовка =====

  function renderHp() {
    const percent = Math.max(0, hp) / CREEP_HP;
    hpFill.style.width = `${percent * 100}%`;
    // В сложном режиме число не показываем — только полоску, как в настоящей игре
    hpText.textContent = hardBox.checked ? '' : Math.max(0, Math.ceil(hp));
  }

  function renderScore() {
    countEl.textContent = `${Math.min(creepIndex, CREEPS_PER_ROUND)} / ${CREEPS_PER_ROUND}`;
    scoreEl.textContent = score;
    goldEl.textContent = gold;
    const best = getBest();
    bestEl.textContent = best ? `${best} / ${CREEPS_PER_ROUND}` : '—';
  }

  // Всплывающая надпись над крипом ("+42", "-23", "Упустил")
  function floatText(text, kind) {
    const el = document.createElement('span');
    el.className = `lh-float ${kind}`;
    el.textContent = text;
    el.style.left = `${rand(35, 65)}%`;
    floatLayer.appendChild(el);
    setTimeout(() => el.remove(), 1000);
  }

  // Короткая анимация: перезапускаем CSS-класс
  function flash(className) {
    creepBtn.classList.remove(className);
    void creepBtn.offsetWidth;
    creepBtn.classList.add(className);
  }

  // ===== Логика =====

  function nextCreep() {
    if (creepIndex >= CREEPS_PER_ROUND) {
      finishRound();
      return;
    }
    creepIndex++;
    hp = CREEP_HP;
    alive = true;
    creepBtn.classList.remove('dead');
    renderHp();
    renderScore();
    scheduleAllyHit();
  }

  // Союзные крипы бьют по таймеру
  function scheduleAllyHit() {
    clearTimeout(allyTimer);
    allyTimer = setTimeout(() => {
      if (!playing || !alive) return;
      const damage = rand(...ALLY_DAMAGE);
      hp -= damage;
      floatText(`-${damage}`, 'ally');
      flash('hit');
      if (hp <= 0) {
        // Крипа добили союзники — мы упустили золото
        killCreep(false);
      } else {
        renderHp();
        scheduleAllyHit();
      }
    }, rand(...ALLY_DELAY));
  }

  // Наш удар
  function attack() {
    if (!playing || !alive || swinging) return;
    swinging = true;
    creepBtn.classList.add('swing');

    // Замах: урон прилетит не сразу, а через ATTACK_POINT мс
    setTimeout(() => {
      creepBtn.classList.remove('swing');
      if (playing && alive) {
        const damage = rand(...MY_DAMAGE);
        hp -= damage;
        flash('hit');
        if (hp <= 0) {
          killCreep(true);
        } else {
          floatText(`-${damage}`, 'mine');
          msg.textContent = 'Рано! Удар ушёл в крипа, а добить его можешь уже не ты.';
          renderHp();
        }
      }
      // Пауза между ударами
      setTimeout(() => (swinging = false), ATTACK_COOLDOWN - ATTACK_POINT);
    }, ATTACK_POINT);
  }

  function killCreep(byMe) {
    alive = false;
    clearTimeout(allyTimer);
    hp = 0;
    renderHp();
    creepBtn.classList.add('dead');

    if (byMe) {
      const reward = rand(36, 46);
      score++;
      gold += reward;
      floatText(`+${reward}`, 'gold');
      msg.textContent = 'Ластхит!';
    } else {
      floatText('Упустил', 'miss');
      msg.textContent = 'Крипа добили союзники. Бей чуть раньше: помни про замах.';
    }
    renderScore();
    setTimeout(nextCreep, 800);
  }

  function finishRound() {
    playing = false;
    clearTimeout(allyTimer);
    startBtn.textContent = 'Ещё раз';
    startBtn.disabled = false;

    const best = getBest();
    if (score > best) setBest(score);
    renderScore();

    let verdict;
    if (score === CREEPS_PER_ROUND) verdict = 'Идеально. Фарм уровня Титана.';
    else if (score >= 8) verdict = 'Уверенный керри, к 10-й минуте будешь с ластхитами.';
    else if (score >= 5) verdict = 'Неплохо, но мидер на линии тебя бы пережал.';
    else if (score >= 2) verdict = 'Хардлайнер был бы рад такому сопернику.';
    else verdict = 'Пятёрка одобряет: ты точно не заберёшь её золото.';

    msg.textContent = `${score} из ${CREEPS_PER_ROUND}, золото: ${gold}. ${verdict}${score > best ? ' Новый рекорд!' : ''}`;
  }

  function startRound() {
    playing = true;
    creepIndex = 0;
    score = 0;
    gold = 0;
    swinging = false;
    startBtn.disabled = true;
    msg.textContent = 'Поехали! Добивай, когда HP крипа меньше твоего урона (52–58).';
    nextCreep();
  }

  // ===== Управление =====

  // Открыть/закрыть игру
  openBtn.addEventListener('click', () => {
    const opening = game.classList.contains('hidden');
    game.classList.toggle('hidden', !opening);
    openBtn.setAttribute('aria-expanded', String(opening));
    openBtn.textContent = opening ? 'Свернуть тренажёр' : 'Потренировать ластхиты';
    if (opening) {
      renderHp();
      renderScore();
      game.scrollIntoView({ behavior: 'smooth', block: 'center' });
    } else {
      playing = false;
      clearTimeout(allyTimer);
      startBtn.disabled = false;
      startBtn.textContent = 'Начать';
    }
  });

  startBtn.addEventListener('click', startRound);
  creepBtn.addEventListener('click', attack);

  // Правая кнопка мыши — как в Доте. preventDefault убирает меню браузера.
  creepBtn.addEventListener('contextmenu', (event) => {
    event.preventDefault();
    attack();
  });

  // Пробел — тоже удар (но не когда печатаешь в поле ввода)
  document.addEventListener('keydown', (event) => {
    if (event.code !== 'Space' || !playing) return;
    const tag = document.activeElement?.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA') return;
    event.preventDefault(); // чтобы страница не прокручивалась
    attack();
  });

  hardBox.addEventListener('change', renderHp);
})();
