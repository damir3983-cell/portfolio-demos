// ===================================================
// Дневник Доты — версия 1.5
//
// Что нового в 1.5:
//  - кнопка "назад" в браузере работает внутри сайта, у каждого экрана свой адрес
//  - главная страница с недавно просмотренными игроками
//  - иконки предметов прямо в тексте разбора от ИИ
//
// Что нового в 1.4:
//  - новый дизайн: шапка с анимированным героем, анимации появления
//  - кнопка "Загрузить ещё" — можно листать всю историю матчей
//  - фильтры по герою и результату (победы / поражения)
//  - подробная страница матча: предметы картинками, все 10 игроков,
//    график преимущества по золоту
// ===================================================

// Адрес OpenDota API — отсюда берём все данные
const API = 'https://api.opendota.com/api';

// Адрес, где Valve хранит картинки и видео героев и предметов.
// OpenDota отдаёт только "хвост" адреса — мы приклеиваем его к этому началу.
const CDN = 'https://cdn.cloudflare.steamstatic.com';

// Сколько матчей грузить за один раз
const PAGE_SIZE = 20;

// Какие поля матчей просим у OpenDota (project = "покажи только эти поля").
// Так ответ меньше и быстрее.
const MATCH_FIELDS = ['hero_id', 'start_time', 'kills', 'deaths', 'assists', 'gold_per_min'];

// ===== 1. Находим элементы на странице =====

// $ — короткое имя для document.getElementById, чтобы не писать длинно каждый раз
const $ = (id) => document.getElementById(id);

const searchForm = $('search-form');
const accountInput = $('account-input');
const refreshBtn = $('refresh-btn');
const statusText = $('status');
const playerInfo = $('player-info');
const matchesScreen = $('matches-screen');
const heroFilter = $('hero-filter');
const resultFilter = $('result-filter');
const summary = $('summary');
const matchesList = $('matches-list');
const moreBtn = $('more-btn');
const matchScreen = $('match-screen');
const matchDetails = $('match-details');
const backBtn = $('back-btn');
const noteInput = $('note-input');
const noteTemplateBtn = $('note-template-btn');
const saveNoteBtn = $('save-note-btn');
const noteSaved = $('note-saved');
const aiBtn = $('ai-btn');
const aiStatus = $('ai-status');
const aiResult = $('ai-result');
const heroVideo = $('hero-video');
const heroGif = $('hero-gif');
const recentBlock = $('recent');
const homeScreen = $('home-screen');
const metaBlock = $('meta');
const playerStats = $('player-stats');

// ===== 2. Данные, пока страница открыта =====

let heroes = {};            // { 1: { name: "Anti-Mage", img: "...", short: "antimage" }, ... }
let items = null;           // справочник предметов { id: { name, img } } — грузим при первом открытии матча
let matches = [];           // загруженные матчи
let offset = 0;             // сколько матчей уже загрузили (для "Загрузить ещё")
let filters = { heroId: '', win: '' }; // текущие фильтры
let currentAccountId = null;
let currentProfile = null;   // профиль игрока (ник, аватарка)
let currentMatch = null;
let notes = {};             // { номер_матча: "текст заметки" }
let customHeaderImage = false; // true, если в папке public лежит своя header.gif

// Отключены ли анимации в системе (настройка "уменьшить движение")
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

// ===== 3. Вспомогательные функции =====

// Экранирование: символы < > & " превращаем в безопасные коды,
// чтобы чужой текст (ник игрока, ответ ИИ) не выполнился как HTML-код.
function escapeHtml(text) {
  return String(text ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// Победил ли игрок. player_slot < 128 — Radiant (Силы Света), иначе Dire.
function isWin(match) {
  return (match.player_slot < 128) === match.radiant_win;
}

// 2537 секунд -> "42:17"
function formatDuration(seconds) {
  const min = Math.floor(seconds / 60);
  const sec = String(seconds % 60).padStart(2, '0');
  return `${min}:${sec}`;
}

// Unix-время -> "16.10.2026, 08:46"
function formatDate(unixTime) {
  return new Date(unixTime * 1000).toLocaleString('ru-RU', {
    day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit',
  });
}

// 12345 -> "12 345" (с пробелами между тысячами)
function formatNumber(n) {
  return typeof n === 'number' ? n.toLocaleString('ru-RU') : '—';
}

// Значение или прочерк, если данных нет
function orDash(value) {
  return value === undefined || value === null ? '—' : value;
}

function heroName(id) {
  return heroes[id]?.name || 'Неизвестный герой';
}

function heroImg(id) {
  return heroes[id]?.img || '';
}

function laneName(p) {
  if (p.is_roaming) return 'Роум';
  return { 1: 'Лёгкая линия', 2: 'Мид', 3: 'Сложная линия', 4: 'Лес' }[p.lane_role] || '';
}

function gameType(match) {
  if (match.game_mode === 23) return 'Турбо';
  if (match.lobby_type === 7) return 'Рейтинговая';
  if (match.lobby_type === 0) return 'Обычная';
  return 'Другой режим';
}

function partyText(p) {
  if (!p.party_size) return '';
  return p.party_size === 1 ? 'Соло' : `Пати из ${p.party_size}`;
}

// Загрузка JSON с проверкой ошибок
async function getJson(url, options) {
  const response = await fetch(url, options);
  const data = await response.json().catch(() => null);
  if (!response.ok) {
    throw new Error(data?.error || 'сервер ответил ошибкой ' + response.status);
  }
  return data;
}

// ===================================================
// 4. ШАПКА: анимированный герой
// ===================================================

// Valve хранит для каждого героя короткое видео, где герой "дышит" и двигается.
// Его мы и показываем в шапке. Если видео не загрузится — показываем картинку.
function setHeaderHero(heroId) {
  if (customHeaderImage) return;      // своя гифка важнее
  const hero = heroes[heroId];
  if (!hero || heroVideo.dataset.heroId === String(heroId)) return;

  heroVideo.dataset.heroId = heroId;
  const renders = `${CDN}/apps/dota2/videos/dota_react/heroes/renders/${hero.short}`;

  // Плавно прячем старого героя
  heroVideo.classList.remove('shown');
  heroGif.classList.remove('shown');

  // Запасной вариант: картинка героя
  const showImage = () => {
    heroGif.onerror = () => {
      heroGif.onerror = null;
      heroGif.src = hero.img; // самая простая картинка, она есть всегда
    };
    heroGif.onload = () => heroGif.classList.add('shown');
    heroGif.src = `${renders}.png`;
  };

  // Если анимации в системе выключены — сразу картинка, без видео
  if (reducedMotion) {
    showImage();
    return;
  }

  // Ждём, пока погаснет старый герой (0.3 сек), и ставим нового
  setTimeout(() => {
    heroVideo.onloadeddata = () => {
      heroVideo.play().catch(() => {}); // play может не сработать — тогда просто кадр
      heroVideo.classList.add('shown');
    };
    heroVideo.onerror = showImage;
    heroVideo.src = `${renders}.webm`;
  }, 300);
}

// Своя гифка: если положить файл header.gif в папку public, в шапке будет она
function tryCustomHeader() {
  return new Promise((resolve) => {
    const probe = new Image();
    probe.onload = () => {
      customHeaderImage = true;
      heroGif.src = 'header.gif';
      heroGif.classList.add('shown');
      resolve();
    };
    probe.onerror = () => resolve();
    probe.src = 'header.gif';
  });
}

// ===================================================
// 5. ЗАГРУЗКА ДАННЫХ
// ===================================================

// Список героев (имена, картинки, роли и статистика по всем игрокам Доты)
async function loadHeroes() {
  const list = await getJson(`${API}/heroStats`);
  for (const hero of list) {
    // Высокий рейтинг: Властелин (6), Божество (7) и Титан (8).
    // Поля называются "6_pick", "6_win" — к ним обращаемся через квадратные скобки.
    const highPick = (hero['6_pick'] || 0) + (hero['7_pick'] || 0) + (hero['8_pick'] || 0);
    const highWin = (hero['6_win'] || 0) + (hero['7_win'] || 0) + (hero['8_win'] || 0);

    heroes[hero.id] = {
      name: hero.localized_name,
      img: CDN + hero.img,
      // "npc_dota_hero_antimage" -> "antimage"
      short: hero.name.replace('npc_dota_hero_', ''),
      roles: hero.roles || [],
      highPick,
      highWin,
      proPick: hero.pro_pick || 0,
      proWin: hero.pro_win || 0,
      proBan: hero.pro_ban || 0,
    };
  }

  // Заполняем выпадающий список героев, по алфавиту
  const sorted = Object.entries(heroes).sort((a, b) => a[1].name.localeCompare(b[1].name));
  for (const [id, hero] of sorted) {
    const option = document.createElement('option');
    option.value = id;
    option.textContent = hero.name;
    heroFilter.appendChild(option);
  }
}

// Профиль: ник, аватарка и ранг.
// Возвращает { ...profile, rankTier, leaderboardRank } или null
async function loadProfile(accountId) {
  try {
    const data = await getJson(`${API}/players/${accountId}`);
    if (!data?.profile) return null;
    return { ...data.profile, rankTier: data.rank_tier, leaderboardRank: data.leaderboard_rank };
  } catch {
    return null;
  }
}

async function loadNotes(accountId) {
  notes = await getJson(`/api/notes/${accountId}`);
}

// Загружает одну "страницу" матчей (20 штук) с учётом фильтров
async function fetchMatchesPage() {
  // URLSearchParams — удобный способ собрать "?limit=20&offset=0&..." без ошибок
  const params = new URLSearchParams({ limit: PAGE_SIZE, offset });
  if (filters.heroId) params.set('hero_id', filters.heroId);
  if (filters.win !== '') params.set('win', filters.win);
  for (const field of MATCH_FIELDS) params.append('project', field);

  let page = await getJson(`${API}/players/${currentAccountId}/matches?${params}`);

  // Подстраховка: если OpenDota не понял список полей — просим без него
  if (page.length && page[0].hero_id === undefined) {
    params.delete('project');
    page = await getJson(`${API}/players/${currentAccountId}/matches?${params}`);
  }
  return page;
}

// Кнопка "Загрузить матчи": проверяем ID и переходим на адрес игрока.
// Саму загрузку сделает route() — она срабатывает при смене адреса.
function onSearch() {
  let accountId = accountInput.value.trim();

  if (!accountId) {
    statusText.textContent = 'Введи свой Dota ID — он есть в профиле в игре';
    return;
  }
  if (!/^\d+$/.test(accountId)) {
    statusText.textContent = 'ID должен состоять только из цифр';
    return;
  }
  // Длинный Steam ID (17 цифр) переводим в короткий Dota ID
  if (accountId.length === 17) {
    accountId = String(BigInt(accountId) - 76561197960265728n);
  }

  const target = `#/player/${accountId}`;
  if (location.hash === target) {
    // Адрес тот же — событие смены адреса не сработает, поэтому загружаем заново сами
    matches = [];
    route();
  } else {
    location.hash = target;
  }
}

// Загружает игрока: профиль, заметки, первую страницу матчей
async function loadPlayer(accountId) {
  currentAccountId = accountId;
  accountInput.value = accountId;
  matches = [];
  filters = { heroId: '', win: '' };
  heroFilter.value = '';
  setResultButtons('');

  statusText.textContent = 'Загружаю...';
  refreshBtn.classList.add('hidden');
  playerInfo.innerHTML = '';
  showScreen('none');

  try {
    // Три запроса параллельно: профиль, заметки, первая страница матчей
    offset = 0;
    const [profile, , page] = await Promise.all([
      loadProfile(accountId),
      loadNotes(accountId),
      fetchMatchesPage(),
    ]);

    // Пока грузили, пользователь мог уйти на другого игрока
    if (currentAccountId !== accountId) return;

    currentProfile = profile;
    renderPlayer(profile, accountId);

    if (page.length === 0) {
      if (!profile) {
        statusText.textContent = 'Игрок с таким ID не найден на OpenDota. Проверь ID: нужен Friend ID из профиля в Доте.';
      } else {
        statusText.textContent =
          'Профиль найден, но OpenDota не видит матчей. Включи в Доте «Открыть доступ к данным матчей», сыграй игру и нажми кнопку ниже.';
        refreshBtn.classList.remove('hidden');
      }
      return;
    }

    saveRecentPlayer(accountId, profile);

    matches = page;
    offset = page.length;
    statusText.textContent = '';
    renderSummary();
    renderMatches(matches, true);
    updateMoreButton(page.length);

    // В шапку — герой, на котором игрок играет чаще всего
    setHeaderHero(favoriteHero().id);

    // Статистика за всё время — грузится в фоне, список матчей её не ждёт
    loadPlayerStats(accountId, profile);
  } catch (error) {
    statusText.textContent = 'Не получилось загрузить: ' + error.message;
  }
}

// Перезагрузка списка при смене фильтра
async function applyFilters() {
  if (!currentAccountId) return;
  offset = 0;
  matchesList.innerHTML = '';
  summary.innerHTML = '';
  moreBtn.classList.add('hidden');
  statusText.textContent = 'Загружаю...';

  try {
    const page = await fetchMatchesPage();
    matches = page;
    offset = page.length;
    statusText.textContent = page.length ? '' : 'С такими фильтрами матчей нет';
    renderSummary();
    renderMatches(matches, true);
    updateMoreButton(page.length);
  } catch (error) {
    statusText.textContent = 'Не получилось загрузить: ' + error.message;
  }
}

// "Загрузить ещё 20"
async function loadMore() {
  moreBtn.disabled = true;
  moreBtn.textContent = 'Загружаю...';
  try {
    const page = await fetchMatchesPage();
    matches = matches.concat(page); // concat — склеить два списка
    offset += page.length;
    renderSummary();
    renderMatches(page, false);     // дорисовываем только новые
    updateMoreButton(page.length);
  } catch (error) {
    statusText.textContent = 'Не получилось загрузить: ' + error.message;
  } finally {
    moreBtn.disabled = false;
    moreBtn.textContent = `Загрузить ещё ${PAGE_SIZE}`;
  }
}

// Если пришло меньше 20 — значит, матчи закончились, кнопку прячем
function updateMoreButton(lastPageSize) {
  moreBtn.classList.toggle('hidden', lastPageSize < PAGE_SIZE);
}

async function requestRefresh() {
  try {
    await getJson(`${API}/players/${currentAccountId}/refresh`, { method: 'POST' });
    statusText.textContent =
      'Запрос отправлен. OpenDota поставил профиль в очередь — подожди несколько минут и снова нажми «Загрузить матчи».';
    refreshBtn.classList.add('hidden');
  } catch (error) {
    statusText.textContent = 'Не получилось отправить запрос: ' + error.message;
  }
}

// ===================================================
// 5.1 ГЛАВНАЯ: мета героев
// ===================================================

// Короткая запись больших чисел: 128 400 -> "128k"
function shortNumber(n) {
  return n >= 1000 ? `${Math.round(n / 1000)}k` : String(n);
}

// Рисует на главной два рейтинга героев по данным OpenDota
function renderMeta() {
  if (metaBlock.hasChildNodes()) return; // уже нарисовано
  const list = Object.entries(heroes).map(([id, h]) => ({ id, ...h }));
  if (!list.length) return;

  // 1) Сильнейшие на высоком рейтинге: лучший винрейт среди героев,
  //    которых берут хотя бы в трети от среднего (чтобы редкий герой
  //    с 10 играми и 80% побед не попал в топ случайно)
  const avgPick = list.reduce((sum, h) => sum + h.highPick, 0) / list.length;
  const strongest = list
    .filter((h) => h.highPick >= avgPick / 3)
    .map((h) => ({ ...h, winrate: (h.highWin / h.highPick) * 100 }))
    .sort((a, b) => b.winrate - a.winrate)
    .slice(0, 8);

  // 2) Про-сцена: самые "спорные" герои — их чаще всех пикают или банят
  const contested = list
    .map((h) => ({ ...h, contest: h.proPick + h.proBan }))
    .filter((h) => h.contest > 0)
    .sort((a, b) => b.contest - a.contest)
    .slice(0, 8);

  // Одна строка рейтинга. Номер здесь уместен: это место в рейтинге.
  const row = (h, index, value, sub) => `
    <li>
      <a class="meta-row" href="https://www.opendota.com/heroes/${h.id}" target="_blank" rel="noopener">
        <span class="meta-place">${index + 1}</span>
        <img src="${h.img}" alt="">
        <span class="meta-name">${escapeHtml(h.name)}</span>
        <span class="meta-value">${value}<small>${sub}</small></span>
      </a>
    </li>`;

  metaBlock.innerHTML = `
    <h2>Мета прямо сейчас</h2>
    <p class="hint">По данным OpenDota. Клик по герою откроет его страницу.</p>
    <div class="meta-columns">
      <div>
        <h3>Сильнейшие на высоком рейтинге</h3>
        <p class="meta-sub">Винрейт у Властелинов, Божеств и Титанов</p>
        <ol class="meta-list">
          ${strongest.map((h, i) => row(h, i, `${h.winrate.toFixed(1)}%`, `игр: ${shortNumber(h.highPick)}`)).join('')}
        </ol>
      </div>
      <div>
        <h3>Горячие в про-сцене</h3>
        <p class="meta-sub">Пики + баны на турнирах (под числом: пики / баны)</p>
        <ol class="meta-list">
          ${contested.map((h, i) => row(h, i, h.contest, `${h.proPick} / ${h.proBan}`)).join('')}
        </ol>
      </div>
    </div>`;
}

// ===================================================
// 5.2 СТАТИСТИКА ПРОФИЛЯ (за всё время)
// ===================================================

// Ранг: rank_tier = 54 -> "Легенда 4". Первая цифра — медаль, вторая — звёзды.
function rankName(rankTier, leaderboardRank) {
  if (!rankTier) return 'Нет ранга';
  const medals = { 1: 'Рекрут', 2: 'Страж', 3: 'Рыцарь', 4: 'Герой', 5: 'Легенда', 6: 'Властелин', 7: 'Божество', 8: 'Титан' };
  const medal = medals[Math.floor(rankTier / 10)] || 'Неизвестно';
  const stars = rankTier % 10;
  if (Math.floor(rankTier / 10) === 8) {
    return leaderboardRank ? `Титан, топ-${leaderboardRank}` : 'Титан';
  }
  return stars ? `${medal} ${stars}` : medal;
}

// Загружает статистику за всё время: победы/поражения, герои, линии
async function loadPlayerStats(accountId, profile) {
  playerStats.innerHTML = '';
  try {
    const [wl, heroGames, counts] = await Promise.all([
      getJson(`${API}/players/${accountId}/wl`),
      getJson(`${API}/players/${accountId}/heroes`),
      getJson(`${API}/players/${accountId}/counts`),
    ]);
    if (currentAccountId !== accountId) return; // пока грузили, открыли другого игрока
    renderPlayerStats({ wl, heroGames, counts, profile });
  } catch {
    // Статистика — дополнение. Не загрузилась — просто не показываем.
  }
}

function renderPlayerStats({ wl, heroGames, counts, profile }) {
  const total = (wl.win || 0) + (wl.lose || 0);
  if (!total) return;
  const winrate = Math.round((wl.win / total) * 100);

  // --- Любимая линия: lane_role 1–4 (0 — "неизвестно", его пропускаем) ---
  const laneNames = { 1: 'Лёгкая линия', 2: 'Мид', 3: 'Сложная линия', 4: 'Лес' };
  let favLane = null;
  let laneTotal = 0;
  for (const [lane, data] of Object.entries(counts?.lane_role || {})) {
    if (!laneNames[lane]) continue;
    laneTotal += data.games;
    if (!favLane || data.games > favLane.games) favLane = { lane, games: data.games };
  }

  // --- Кор или саппорт: смотрим роли героев, на которых сыграно больше всего ---
  // Герой считается саппортом, если у него есть роль Support и нет роли Carry.
  let supportGames = 0;
  let coreGames = 0;
  for (const h of heroGames) {
    const roles = heroes[h.hero_id]?.roles || [];
    if (roles.includes('Support') && !roles.includes('Carry')) supportGames += h.games;
    else coreGames += h.games;
  }
  const roleTotal = supportGames + coreGames;
  const isCore = coreGames >= supportGames;
  const rolePercent = roleTotal ? Math.round(((isCore ? coreGames : supportGames) / roleTotal) * 100) : 0;

  // --- Топ-5 героев по числу игр ---
  const topHeroes = [...heroGames].sort((a, b) => b.games - a.games).slice(0, 5).filter((h) => h.games > 0);

  playerStats.innerHTML = `
    <h2>За всё время</h2>
    <div class="summary">
      <div class="summary-item"><span>Матчей</span><b>${formatNumber(total)}</b></div>
      <div class="summary-item"><span>Винрейт</span><b class="${winrate >= 50 ? 'win-text' : 'loss-text'}">${winrate}%</b></div>
      <div class="summary-item"><span>Ранг</span><b class="small">${rankName(profile?.rankTier, profile?.leaderboardRank)}</b></div>
      <div class="summary-item"><span>Любимая роль</span><b class="small">${isCore ? 'Кор' : 'Саппорт'}</b> <span>${rolePercent}% игр</span></div>
      ${favLane ? `<div class="summary-item"><span>Любимая линия</span><b class="small">${laneNames[favLane.lane]}</b> <span>${Math.round((favLane.games / laneTotal) * 100)}% разобранных игр</span></div>` : ''}
    </div>

    <h3>Больше всего игр</h3>
    <div class="top-heroes">
      ${topHeroes.map((h) => {
        const wr = Math.round((h.win / h.games) * 100);
        return `
          <button type="button" class="top-hero" data-hero="${h.hero_id}" title="Показать только матчи на этом герое">
            <img src="${heroImg(h.hero_id)}" alt="">
            <span class="top-hero-name">${escapeHtml(heroName(h.hero_id))}</span>
            <span class="top-hero-stats">игр: ${formatNumber(h.games)}, <span class="${wr >= 50 ? 'win-text' : 'loss-text'}">${wr}%</span></span>
          </button>`;
      }).join('')}
    </div>`;
}

// Клик по герою из топа — включаем фильтр по нему
playerStats.addEventListener('click', (event) => {
  const btn = event.target.closest('.top-hero');
  if (!btn) return;
  heroFilter.value = btn.dataset.hero;
  filters.heroId = btn.dataset.hero;
  applyFilters();
  document.querySelector('.filters').scrollIntoView({ behavior: reducedMotion ? 'auto' : 'smooth', block: 'start' });
});

// ===================================================
// 6. СПИСОК МАТЧЕЙ
// ===================================================

// Переключение экранов: 'list' — список, 'match' — один матч, 'none' — ничего
function showScreen(name) {
  homeScreen.classList.toggle('hidden', name !== 'home');
  matchesScreen.classList.toggle('hidden', name !== 'list');
  matchScreen.classList.toggle('hidden', name !== 'match');
}

// Ник вставляем через textContent — это защита от вставки HTML-кода в ник
function renderPlayer(profile, accountId) {
  playerInfo.innerHTML = '';
  if (!profile) return;

  const wrapper = document.createElement('div');
  wrapper.className = 'player';

  const avatar = document.createElement('img');
  avatar.src = profile.avatarmedium;
  avatar.alt = '';

  const info = document.createElement('div');
  const name = document.createElement('div');
  name.className = 'player-name';
  name.textContent = profile.personaname;

  const link = document.createElement('a');
  link.href = `https://www.opendota.com/players/${accountId}`;
  link.target = '_blank';
  link.rel = 'noopener';
  link.textContent = 'Профиль на OpenDota';

  info.append(name, link);
  wrapper.append(avatar, info);
  playerInfo.appendChild(wrapper);
}

// Самый частый герой среди загруженных матчей: { id, count }
function favoriteHero() {
  const counts = {};
  for (const m of matches) counts[m.hero_id] = (counts[m.hero_id] || 0) + 1;
  let best = { id: null, count: 0 };
  for (const [id, count] of Object.entries(counts)) {
    if (count > best.count) best = { id, count };
  }
  return best;
}

function renderSummary() {
  const total = matches.length;
  if (!total) {
    summary.innerHTML = '';
    return;
  }

  const wins = matches.filter(isWin).length;
  const winrate = Math.round((wins / total) * 100);
  const avg = (field) => {
    const values = matches.map((m) => m[field]).filter((v) => typeof v === 'number');
    return values.length ? values.reduce((a, b) => a + b, 0) / values.length : null;
  };
  const k = avg('kills');
  const d = avg('deaths');
  const a = avg('assists');
  const gpm = avg('gold_per_min');
  const fav = favoriteHero();

  // Блок "Чаще всего" показываем, только если не выбран фильтр по герою
  const favHtml = filters.heroId
    ? ''
    : `<div class="summary-item fav"><span>Чаще всего</span><b>${escapeHtml(heroName(fav.id))}</b> <span>${fav.count} из ${total}</span></div>`;

  summary.innerHTML = `
    <div class="summary-item"><span>Загружено матчей</span><b>${total}</b></div>
    <div class="summary-item"><span>Победы и поражения</span><b>${wins} – ${total - wins}</b></div>
    <div class="summary-item"><span>Винрейт</span><b class="${winrate >= 50 ? 'win-text' : 'loss-text'}">${winrate}%</b></div>
    <div class="summary-item kda"><span>Средний K / D / A</span><b>${k !== null ? `${k.toFixed(1)} / ${d.toFixed(1)} / ${a.toFixed(1)}` : '—'}</b></div>
    ${gpm !== null ? `<div class="summary-item"><span>Средний GPM</span><b>${Math.round(gpm)}</b></div>` : ''}
    ${favHtml}
  `;
}

// Рисует строки матчей. reset = true — очистить список и нарисовать заново
function renderMatches(list, reset) {
  if (reset) matchesList.innerHTML = '';

  list.forEach((match, index) => {
    const win = isWin(match);
    const row = document.createElement('div');
    row.className = 'match-row ' + (win ? 'win' : 'loss');
    row.tabIndex = 0;                       // строку можно выбрать клавишей Tab
    row.setAttribute('role', 'button');
    row.setAttribute('aria-label', `${heroName(match.hero_id)}, ${win ? 'победа' : 'поражение'}`);

    // Анимация появления: каждая строка выезжает чуть позже предыдущей.
    // --i — CSS-переменная с номером строки (используется в style.css).
    // Math.min — чтобы при 100 матчах последний не ждал 3 секунды.
    row.classList.add('enter');
    row.style.setProperty('--i', Math.min(index, 15));

    row.innerHTML = `
      <div class="hero-cell">
        <img class="hero-img" src="${heroImg(match.hero_id)}" alt="">
        <span>${escapeHtml(heroName(match.hero_id))}</span>
      </div>
      <div class="result">${win ? 'Победа' : 'Поражение'}</div>
      <div>${orDash(match.kills)} / ${orDash(match.deaths)} / ${orDash(match.assists)}</div>
      <div class="col-gpm cell-muted">${orDash(match.gold_per_min)}</div>
      <div class="col-duration cell-muted">${formatDuration(match.duration)}</div>
      <div class="cell-muted">${formatDate(match.start_time)}</div>
      <div title="Есть заметка">${notes[match.match_id] ? '📝' : ''}</div>
    `;

    row.addEventListener('click', () => openMatch(match));
    row.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        openMatch(match);
      }
    });

    // Когда анимация закончилась — убираем класс, чтобы она не повторилась
    row.addEventListener('animationend', () => row.classList.remove('enter'), { once: true });

    matchesList.appendChild(row);
  });
}

// Кнопки "Все / Победы / Поражения"
function setResultButtons(value) {
  for (const btn of resultFilter.querySelectorAll('button')) {
    btn.setAttribute('aria-pressed', String(btn.dataset.win === value));
  }
}

// ===================================================
// 7. СТРАНИЦА МАТЧА
// ===================================================

// loadItems может вызываться сразу из двух мест (страница матча и разбор ИИ).
// Запоминаем сам "процесс загрузки" (промис), чтобы справочник не качался дважды.
let itemsPromise = null;

function loadItems() {
  if (!itemsPromise) {
    itemsPromise = getJson('/api/items')
      .catch(() => ({})) // без справочника покажем матч без картинок предметов
      .then((data) => {
        items = data;
        buildItemMatcher();
        return items;
      });
  }
  return itemsPromise;
}

// ===== Иконки предметов в тексте разбора =====

// Сленговые названия предметов -> их ключ в справочнике.
// Пиши в нижнем регистре. Хочешь добавить свой сленг — допиши строку.
const ITEM_SLANG = {
  'бкб': 'black_king_bar',
  'блинк': 'blink',
  'бфури': 'bfury',
  'баттлфури': 'bfury',
  'манта': 'manta',
  'сатаник': 'satanic',
  'дезоль': 'desolator',
  'дезолятор': 'desolator',
  'мкб': 'monkey_king_bar',
  'баттерфляй': 'butterfly',
  'бабочка': 'butterfly',
  'дедалус': 'greater_crit',
  'даедалус': 'greater_crit',
  'аганим': 'ultimate_scepter',
  'аган': 'ultimate_scepter',
  'линка': 'sphere',
  'линкенс': 'sphere',
  'хекс': 'sheepstick',
  'еул': 'cyclone',
  'еулы': 'cyclone',
  'форс': 'force_staff',
  'форсстафф': 'force_staff',
  'глиммер': 'glimmer_cape',
  'мека': 'mekansm',
  'гривсы': 'guardian_greaves',
  'пайп': 'pipe',
  'рапира': 'rapier',
  'скади': 'skadi',
  'харт': 'heart',
  'ассолт': 'assault',
  'кираса': 'assault',
  'шива': 'shivas_guard',
  'мьёльнир': 'mjollnir',
  'мьелнир': 'mjollnir',
  'мжолнир': 'mjollnir',
  'мельстром': 'maelstrom',
  'арканы': 'arcane_boots',
  'транквилы': 'tranquil_boots',
  'фазы': 'phase_boots',
  'треды': 'power_treads',
  'бутылка': 'bottle',
  'абиссал': 'abyssal_blade',
  'харикейн': 'hurricane_pike',
  'солар': 'solar_crest',
  'рефрешер': 'refresher',
  'октарин': 'octarine_core',
  'аегис': 'aegis',
  'аэгис': 'aegis',
  'сильвер': 'silver_edge',
  'радианс': 'radiance',
  'диффуза': 'diffusal_blade',
  'эхо': 'echo_sabre',
  'харпун': 'harpoon',
  'гарпун': 'harpoon',
  'нулики': 'null_talisman',
  'враисы': 'wraith_band',
  'браслеты': 'bracer',
};

let itemMatcher = null;   // одно большое регулярное выражение со всеми названиями
let itemLookup = {};      // "black king bar" / "бкб" -> предмет

function buildItemMatcher() {
  itemLookup = {};
  const byKey = {};
  for (const item of Object.values(items)) {
    if (item.key) byKey[item.key] = item;
    // Пропускаем рецепты, предметы без картинки и слишком короткие названия
    if (!item.img || !item.name || item.name.startsWith('Recipe') || item.name.length < 4) continue;
    itemLookup[item.name.toLowerCase()] = item;
  }
  for (const [slang, key] of Object.entries(ITEM_SLANG)) {
    if (byKey[key]?.img) itemLookup[slang] = byKey[key];
  }

  const names = Object.keys(itemLookup);
  if (!names.length) return;

  // Длинные названия первыми: иначе "Dagger" найдётся раньше, чем "Blink Dagger"
  names.sort((a, b) => b.length - a.length);
  // Экранируем спецсимволы регулярных выражений (точки, скобки и т.д.)
  const escaped = names.map((n) => escapeHtml(n).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));

  // (?<![\p{L}\d]) и (?![\p{L}]) — "название не внутри другого слова".
  // Второй кусок — русские окончания: "блинка", "блинком", "линкой" тоже найдутся.
  // Флаги: g — искать все, i — без учёта регистра, u — понимать русские буквы.
  itemMatcher = new RegExp(`(?<![\\p{L}\\d])(${escaped.join('|')})(а|я|у|ю|ом|ем|ой|ей|е|и|ы|ов|ам|ами|ах|й)?(?![\\p{L}])`, 'giu');
}

// Вставляет иконки перед названиями предметов в (уже экранированный) текст
function addItemIcons(text) {
  if (!itemMatcher) return text;
  return text.replace(itemMatcher, (whole, name, ending) => {
    const item = itemLookup[name.toLowerCase()];
    // Английские названия не склоняются: "Blinkом" не бывает — такое не трогаем
    if (!item || (ending && /[a-z]/i.test(name))) return whole;
    return `<span class="inline-item"><img src="${CDN}${item.img}" alt="">${whole}</span>`;
  });
}

function itemImg(id, extraClass = '') {
  if (!id) return '';
  const item = items[id];
  if (!item) return '';
  const name = escapeHtml(item.name);
  return `<img class="item ${extraClass}" src="${CDN}${item.img}" alt="${name}" title="${name}" loading="lazy">`;
}

// Клик по матчу: меняем адрес, остальное сделает route()
function openMatch(match) {
  listScrollY = window.scrollY;   // запоминаем, докуда долистали список
  cameFromList = true;            // чтобы кнопка "Все матчи" работала как "назад"
  location.hash = `#/player/${currentAccountId}/match/${match.match_id}`;
}

// Показывает страницу матча. full — полные данные, если они уже загружены
async function showMatch(match, full = null) {
  currentMatch = match;
  showScreen('match');

  // Анимация въезда справа: убираем класс и добавляем снова, чтобы она проигралась
  matchScreen.classList.remove('enter');
  void matchScreen.offsetWidth; // трюк: заставляет браузер "заметить" удаление класса
  matchScreen.classList.add('enter');
  window.scrollTo({ top: matchScreen.offsetTop - 20, behavior: reducedMotion ? 'auto' : 'smooth' });

  noteInput.value = notes[match.match_id] || '';
  noteSaved.textContent = '';
  loadAnalysis(match);

  matchDetails.innerHTML = '<p class="status">Загружаю подробности матча...</p>';

  try {
    // Полные данные матча + справочник предметов — параллельно
    const [data] = await Promise.all([full || getJson(`${API}/matches/${match.match_id}`), loadItems()]);
    if (currentMatch !== match) return; // пока грузили, открыли другой матч
    renderMatchDetails(match, data);
  } catch (error) {
    if (currentMatch !== match) return;
    matchDetails.innerHTML = `<p class="status">Не получилось загрузить подробности: ${escapeHtml(error.message)}</p>`;
  }
}

// Открыть матч по номеру из адреса. Если его нет среди загруженных
// (например, открыли ссылку на матч напрямую) — достаём данные из полного матча.
async function openMatchById(matchId) {
  let match = matches.find((m) => String(m.match_id) === matchId);
  let full = null;

  if (!match) {
    showScreen('none');
    statusText.textContent = 'Загружаю матч...';
    try {
      full = await getJson(`${API}/matches/${matchId}`);
    } catch (error) {
      statusText.textContent = 'Не получилось загрузить матч: ' + error.message;
      return;
    }
    const me = full.players?.find((p) => String(p.account_id) === currentAccountId);
    if (!me) {
      statusText.textContent = 'Этого игрока нет в матче ' + matchId;
      return;
    }
    statusText.textContent = '';
    // Собираем "короткую" версию матча — как в списке
    match = {
      match_id: full.match_id,
      player_slot: me.player_slot,
      radiant_win: full.radiant_win,
      hero_id: me.hero_id,
      duration: full.duration,
      start_time: full.start_time,
    };
  }
  showMatch(match, full);
}

function renderMatchDetails(match, full) {
  // Находим себя среди 10 игроков: по номеру слота (он уникален в матче)
  const me = full.players.find((p) => p.player_slot === match.player_slot) || {};
  const win = isWin(match);
  const tags = [gameType(full), laneName(me), partyText(me)].filter(Boolean);

  // Запоминаем соперников по линии — пригодятся для подсказок в заметке
  laneOpponents = findLaneOpponents(full, me);

  const finalItems = [0, 1, 2, 3, 4, 5].map((i) => me[`item_${i}`]);
  const backpack = [0, 1, 2].map((i) => me[`backpack_${i}`]).filter(Boolean);

  matchDetails.innerHTML = `
    <div class="match-top">
      <img src="${heroImg(match.hero_id)}" alt="">
      <div>
        <h2>${escapeHtml(heroName(match.hero_id))}</h2>
        <div>
          <b class="${win ? 'win-text' : 'loss-text'}">${win ? 'Победа' : 'Поражение'}</b>
          <span class="cell-muted">за ${formatDuration(full.duration)}, ${formatDate(full.start_time)}</span>
        </div>
        <div class="tags">${tags.map((t) => `<span class="tag">${t}</span>`).join('')}</div>
      </div>
    </div>

    <div class="stats">
      <div class="stat"><span>K / D / A</span><b>${me.kills} / ${me.deaths} / ${me.assists}</b></div>
      <div class="stat"><span>Золото в минуту</span><b>${orDash(me.gold_per_min)}</b></div>
      <div class="stat"><span>Опыт в минуту</span><b>${orDash(me.xp_per_min)}</b></div>
      <div class="stat"><span>Ластхиты / денаи</span><b>${orDash(me.last_hits)} / ${orDash(me.denies)}</b></div>
      <div class="stat"><span>Ценность героя</span><b>${formatNumber(me.net_worth)}</b></div>
      <div class="stat"><span>Урон по героям</span><b>${formatNumber(me.hero_damage)}</b></div>
      <div class="stat"><span>Урон по строениям</span><b>${formatNumber(me.tower_damage)}</b></div>
      <div class="stat"><span>Лечение</span><b>${formatNumber(me.hero_healing)}</b></div>
    </div>

    <div class="section">
      <h3>Предметы</h3>
      <div class="items">
        ${finalItems.map((id) => itemImg(id) || '<span class="item"></span>').join('')}
        ${itemImg(me.item_neutral, 'neutral')}
        ${backpack.length ? `<span class="items-label">В рюкзаке</span>${backpack.map((id) => itemImg(id, 'small')).join('')}` : ''}
      </div>
    </div>

    <div class="section" id="gold-section"></div>

    <div class="section">
      <h3>Все игроки</h3>
      <div class="table-scroll">${renderScoreboard(full, me)}</div>
    </div>

    <a class="opendota-link" href="https://www.opendota.com/matches/${match.match_id}" target="_blank" rel="noopener">Открыть матч на OpenDota</a>
  `;

  renderGoldChart($('gold-section'), full, me);
}

// Таблица всех 10 игроков, разделённая по командам
function renderScoreboard(full, me) {
  const myRadiant = me.player_slot < 128;

  const teamRows = (isRadiant) => {
    const team = full.players.filter((p) => (p.player_slot < 128) === isRadiant);
    const teamName = isRadiant ? 'Силы Света' : 'Силы Тьмы';
    const mine = isRadiant === myRadiant ? ' — твоя команда' : '';
    const won = isRadiant === full.radiant_win;

    const rows = team.map((p) => {
      // personaname — ник, его придумывает игрок, поэтому обязательно escapeHtml
      const name = p.personaname ? escapeHtml(p.personaname) : '<span class="cell-muted">Скрытый профиль</span>';
      const itemsHtml = [0, 1, 2, 3, 4, 5].map((i) => itemImg(p[`item_${i}`], 'small')).join('');
      return `
        <tr class="${p === me ? 'me' : ''}">
          <td><div class="sb-hero"><img src="${heroImg(p.hero_id)}" alt="">${escapeHtml(heroName(p.hero_id))}</div></td>
          <td class="sb-name">${name}</td>
          <td>${p.kills} / ${p.deaths} / ${p.assists}</td>
          <td>${orDash(p.last_hits)} / ${orDash(p.denies)}</td>
          <td>${orDash(p.gold_per_min)}</td>
          <td>${formatNumber(p.net_worth)}</td>
          <td>${formatNumber(p.hero_damage)}</td>
          <td><div class="sb-items">${itemsHtml}</div></td>
        </tr>`;
    });

    return `
      <tr class="team-row"><td colspan="8">
        <span class="${won ? 'win-text' : 'loss-text'}">${teamName}</span>
        <span class="cell-muted">${won ? 'победа' : 'поражение'}${mine}</span>
      </td></tr>
      ${rows.join('')}`;
  };

  // Сначала своя команда
  return `
    <table class="scoreboard">
      <thead><tr>
        <th>Герой</th><th>Игрок</th><th>K / D / A</th><th>ЛХ / ДН</th>
        <th>GPM</th><th>Ценность</th><th>Урон</th><th>Предметы</th>
      </tr></thead>
      <tbody>${teamRows(myRadiant)}${teamRows(!myRadiant)}</tbody>
    </table>`;
}

// ===== График преимущества по золоту =====
// Рисуем сами, без библиотек, с помощью SVG — языка векторной графики,
// который браузер понимает так же, как HTML.
function renderGoldChart(container, full, me) {
  const raw = full.radiant_gold_adv;
  if (!Array.isArray(raw) || raw.length < 2) {
    container.innerHTML = `
      <h3>Преимущество по золоту</h3>
      <p class="chart-note">Для этого матча нет подробного разбора от OpenDota, поэтому графика нет.
      Его можно заказать на странице матча на OpenDota (кнопка «Request Parse»).</p>`;
    return;
  }

  // radiant_gold_adv — преимущество Сил Света по минутам.
  // Если мы за Силы Тьмы — переворачиваем знак, чтобы "вверх" всегда значило "мы впереди".
  const sign = me.player_slot < 128 ? 1 : -1;
  const data = raw.map((v) => v * sign);

  // Размеры рисунка (во "внутренних" единицах SVG — потом он растянется по ширине)
  const W = 800;
  const H = 240;
  const pad = { top: 16, right: 16, bottom: 28, left: 52 };
  const innerW = W - pad.left - pad.right;
  const innerH = H - pad.top - pad.bottom;

  // Масштаб по вертикали: симметричный, кратный 5000 (чтобы подписи были круглые)
  const maxAbs = Math.max(5000, Math.ceil(Math.max(...data.map(Math.abs)) / 5000) * 5000);

  // Функции перевода "минута -> X" и "золото -> Y"
  const x = (i) => pad.left + (i / (data.length - 1)) * innerW;
  const y = (v) => pad.top + innerH / 2 - (v / maxAbs) * (innerH / 2);
  const zeroY = y(0);

  // Линия графика: "M x,y L x,y L x,y ..." — команды SVG "перейти" и "провести линию"
  const linePath = data.map((v, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(' ');
  // Площадь под линией: линия + спуск к нулю + возврат в начало
  const areaPath = `${linePath} L${x(data.length - 1)},${zeroY} L${x(0)},${zeroY} Z`;

  // Подписи по вертикали: +max, +max/2, 0, -max/2, -max
  const fmtK = (v) => (v === 0 ? '0' : `${v > 0 ? '+' : '−'}${Math.abs(v) / 1000}k`);
  const yTicks = [maxAbs, maxAbs / 2, 0, -maxAbs / 2, -maxAbs];

  // Подписи по горизонтали: каждые 10 минут (или 5, если игра короткая)
  const step = data.length > 30 ? 10 : 5;
  const xTicks = [];
  for (let m = 0; m < data.length; m += step) xTicks.push(m);

  container.innerHTML = `
    <h3>Преимущество твоей команды по золоту</h3>
    <div class="chart-wrap">
      <svg viewBox="0 0 ${W} ${H}" role="img" aria-label="График преимущества по золоту по минутам">
        <defs>
          <!-- clipPath — "ножницы": выше нуля красим зелёным, ниже — красным -->
          <clipPath id="clip-above"><rect x="0" y="0" width="${W}" height="${zeroY}"/></clipPath>
          <clipPath id="clip-below"><rect x="0" y="${zeroY}" width="${W}" height="${H - zeroY}"/></clipPath>
        </defs>

        ${yTicks.map((v) => `
          <line x1="${pad.left}" x2="${W - pad.right}" y1="${y(v)}" y2="${y(v)}"
                stroke="${v === 0 ? '#5a6474' : '#2c3644'}" stroke-width="1"/>
          <text x="${pad.left - 8}" y="${y(v) + 4}" text-anchor="end" fill="#8a94a3" font-size="12">${fmtK(v)}</text>
        `).join('')}

        ${xTicks.map((m) => `
          <text x="${x(m)}" y="${H - 8}" text-anchor="middle" fill="#8a94a3" font-size="12">${m} мин</text>
        `).join('')}

        <path d="${areaPath}" fill="#5ea83a" fill-opacity="0.28" clip-path="url(#clip-above)"/>
        <path d="${areaPath}" fill="#cc4436" fill-opacity="0.28" clip-path="url(#clip-below)"/>
        <path d="${linePath}" fill="none" stroke="#5ea83a" stroke-width="2" clip-path="url(#clip-above)"/>
        <path d="${linePath}" fill="none" stroke="#cc4436" stroke-width="2" clip-path="url(#clip-below)"/>

        <!-- Подписи прямо на графике: не только цвет, но и слова -->
        <text x="${pad.left + 8}" y="${pad.top + 14}" fill="#dfe3ea" font-size="13">Твоя команда впереди</text>
        <text x="${pad.left + 8}" y="${H - pad.bottom - 8}" fill="#dfe3ea" font-size="13">Твоя команда позади</text>

        <!-- Перекрестие при наведении (сначала спрятано) -->
        <line class="cross" x1="0" x2="0" y1="${pad.top}" y2="${H - pad.bottom}" stroke="#dfe3ea" stroke-width="1" visibility="hidden"/>
        <circle class="cross-dot" r="5" fill="#dfe3ea" stroke="#1a212b" stroke-width="2" visibility="hidden"/>

        <!-- Невидимый прямоугольник, который "ловит" движение мыши -->
        <rect class="hit" x="${pad.left}" y="0" width="${innerW}" height="${H}" fill="transparent"/>
      </svg>
      <div class="chart-tooltip hidden"></div>
    </div>`;

  // ----- Наведение мыши: показываем значение в ближайшей минуте -----
  const svg = container.querySelector('svg');
  const hit = container.querySelector('.hit');
  const cross = container.querySelector('.cross');
  const dot = container.querySelector('.cross-dot');
  const tooltip = container.querySelector('.chart-tooltip');

  const show = (event) => {
    // Переводим координату мыши на экране в координату внутри SVG
    const rect = svg.getBoundingClientRect();
    const svgX = ((event.clientX - rect.left) / rect.width) * W;
    const i = Math.round(((svgX - pad.left) / innerW) * (data.length - 1));
    const minute = Math.max(0, Math.min(data.length - 1, i));
    const v = data[minute];

    cross.setAttribute('x1', x(minute));
    cross.setAttribute('x2', x(minute));
    dot.setAttribute('cx', x(minute));
    dot.setAttribute('cy', y(v));
    cross.setAttribute('visibility', 'visible');
    dot.setAttribute('visibility', 'visible');

    const sign = v > 0 ? '+' : v < 0 ? '−' : '';
    tooltip.textContent = `${minute} мин: ${sign}${formatNumber(Math.abs(v))} золота`;
    tooltip.style.left = `${(x(minute) / W) * rect.width + 12}px`;
    tooltip.style.top = `${(y(v) / H) * rect.height + 12}px`;
    tooltip.classList.remove('hidden');
  };

  const hide = () => {
    cross.setAttribute('visibility', 'hidden');
    dot.setAttribute('visibility', 'hidden');
    tooltip.classList.add('hidden');
  };

  // pointer-события работают и для мыши, и для пальца на телефоне
  hit.addEventListener('pointermove', show);
  hit.addEventListener('pointerdown', show);
  hit.addEventListener('pointerleave', hide);
}

// Кнопка "Все матчи"
function goBack() {
  if (cameFromList) {
    history.back(); // как кнопка "назад" в браузере
  } else {
    location.hash = `#/player/${currentAccountId}`;
  }
}

// Показывает список матчей (уже загруженный)
function showList() {
  currentMatch = null;
  cameFromList = false;
  statusText.textContent = '';
  showScreen('list');
  // Обновляем значки заметок в списке (без повторной анимации)
  for (const row of matchesList.children) row.classList.remove('enter');
  const rows = [...matchesList.children];
  matches.forEach((m, i) => {
    if (rows[i]) rows[i].lastElementChild.textContent = notes[m.match_id] ? '📝' : '';
  });
  // Возвращаемся туда, где были в списке
  window.scrollTo(0, listScrollY);
}

// ===================================================
// 8. ЗАМЕТКИ
// ===================================================

// ===== Подсказки для заметки =====
// ИИ не видит реплей, поэтому чем подробнее заметка — тем лучше разбор.
// Кнопка "Вставить подсказки" вставляет готовые вопросы, на которые остаётся ответить.

let laneOpponents = []; // герои, против которых игрок стоял на линии (если OpenDota это знает)

// Лёгкая линия одной команды = сложная линия другой, мид = мид
function findLaneOpponents(full, me) {
  const opposite = { 1: 3, 2: 2, 3: 1 };
  if (!me.lane_role || me.is_roaming || !opposite[me.lane_role]) return [];
  const myRadiant = me.player_slot < 128;
  return full.players
    .filter((p) => (p.player_slot < 128) !== myRadiant)
    .filter((p) => !p.is_roaming && p.lane_role === opposite[me.lane_role])
    .map((p) => heroName(p.hero_id));
}

function insertNoteTemplate() {
  const lane = laneOpponents.length
    ? `Линия: стоял против ${laneOpponents.join(' и ')}. Как прошла (кто кого задавил, были ли ганки, сколько ластхитов к 10 минуте):`
    : 'Линия: против кого стоял и как прошла (кто кого задавил, были ли ганки):';

  const template = [
    lane,
    'Ключевые моменты (файты, смерти, Рошан — что запомнилось и на какой минуте):',
    'Что пошло не так:',
    'Что получилось:',
    'Вопрос к ИИ:',
  ].join('\n\n');

  // Если что-то уже написано — добавляем подсказки ниже, а не стираем
  noteInput.value = noteInput.value.trim() ? `${noteInput.value.trim()}\n\n${template}` : template;

  // Ставим курсор в конец первой строки, чтобы сразу начать писать
  noteInput.focus();
  const firstLineEnd = noteInput.value.indexOf('\n') === -1 ? noteInput.value.length : noteInput.value.indexOf(lane) + lane.length;
  noteInput.setSelectionRange(firstLineEnd, firstLineEnd);
  noteSaved.textContent = '';
}


async function setNote(matchId, text) {
  await getJson(`/api/notes/${currentAccountId}/${matchId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text }),
  });
  if (text.trim() === '') delete notes[matchId];
  else notes[matchId] = text;
}

async function saveNote() {
  if (!currentMatch) return;
  noteSaved.textContent = 'Сохраняю...';
  try {
    await setNote(currentMatch.match_id, noteInput.value);
    noteSaved.textContent = 'Сохранено';
  } catch (error) {
    noteSaved.textContent = 'Не сохранилось: ' + error.message + '. Сервер запущен?';
  }
}

// ===================================================
// 9. ИИ-РАЗБОР
// ===================================================

// Markdown от нейросети -> простой HTML. Сначала экранируем, потом добавляем свои теги.
function renderMarkdown(text) {
  const lines = escapeHtml(text).split('\n');
  let html = '';
  let inList = false;
  const itemRe = /^([-*•]|\d+[.)])\s+/;

  // Строка вида "Оценка: 6/10 — вердикт" (ИИ иногда добавляет ** вокруг)
  const scoreRe = /^\**\s*Оценка\s*:?\s*\**\s*(\d{1,2})\s*\/\s*10\s*\**\s*[—–-]?\s*(.*)$/i;

  for (let line of lines) {
    line = line.trim();

    // Оценку рисуем отдельным крупным блоком
    const score = line.match(scoreRe);
    if (score) {
      const n = Math.min(10, Number(score[1]));
      // Цвет оценки: 7+ зелёный, 4–6 золотой, до 3 красный (и число рядом — не только цвет)
      const level = n >= 7 ? 'good' : n >= 4 ? 'mid' : 'bad';
      const verdict = score[2].replace(/\*\*/g, '');
      html += `<div class="ai-score"><span class="score score-${level}">${n}<small>/10</small></span><span class="verdict">${verdict}</span></div>`;
      continue; // эта строка обработана, переходим к следующей
    }

    line = addItemIcons(line); // иконки предметов
    line = line.replace(/\*\*(.+?)\*\*/g, '<b>$1</b>');
    const isItem = itemRe.test(line);
    if (!isItem && inList) {
      html += '</ul>';
      inList = false;
    }
    if (/^#{1,6}\s+/.test(line)) {
      html += `<h4>${line.replace(/^#{1,6}\s+/, '')}</h4>`;
    } else if (isItem) {
      if (!inList) {
        html += '<ul>';
        inList = true;
      }
      html += `<li>${line.replace(itemRe, '')}</li>`;
    } else if (line) {
      html += `<p>${line}</p>`;
    }
  }
  if (inList) html += '</ul>';
  return html;
}

function showAnalysis(analysis) {
  if (!analysis) {
    aiResult.classList.add('hidden');
    aiResult.innerHTML = '';
    aiBtn.textContent = 'Разобрать игру';
    return;
  }
  const date = new Date(analysis.createdAt).toLocaleString('ru-RU');
  aiResult.innerHTML = renderMarkdown(analysis.text) + `<p class="ai-date">Разбор от ${date}</p>`;
  aiResult.classList.remove('hidden');
  aiBtn.textContent = 'Разобрать заново';
}

async function loadAnalysis(match) {
  showAnalysis(null);
  aiStatus.textContent = '';
  try {
    // Справочник предметов нужен для иконок в тексте — ждём и его
    const [data] = await Promise.all([
      getJson(`/api/analysis/${currentAccountId}/${match.match_id}`),
      loadItems(),
    ]);
    if (currentMatch === match) showAnalysis(data.analysis);
  } catch {
    // не страшно — просто не покажем старый разбор
  }
}

async function analyze() {
  const match = currentMatch;
  if (!match) return;
  aiBtn.disabled = true;

  try {
    // Несохранённую заметку сохраняем, чтобы ИИ её учёл
    if (noteInput.value !== (notes[match.match_id] || '')) {
      aiStatus.textContent = 'Сохраняю заметку...';
      await setNote(match.match_id, noteInput.value);
      noteSaved.textContent = 'Сохранено';
    }
    aiStatus.textContent = 'ИИ думает, это может занять до минуты...';
    const data = await getJson(`/api/analysis/${currentAccountId}/${match.match_id}`, { method: 'POST' });
    if (currentMatch !== match) return;
    aiStatus.textContent = '';
    showAnalysis(data.analysis);
  } catch (error) {
    if (currentMatch === match) aiStatus.textContent = 'Не получилось: ' + error.message;
  } finally {
    aiBtn.disabled = false;
  }
}

// ===================================================
// 10. НАВИГАЦИЯ: адреса страниц и кнопка "назад" в браузере
// ===================================================
//
// Раньше сайт был одной страницей, и кнопка "назад" в браузере уводила с сайта.
// Теперь у каждого экрана свой адрес после знака # (это называется "хеш"):
//   #/                              — главная
//   #/player/843808443              — матчи игрока
//   #/player/843808443/match/9000…  — один матч
// Браузер запоминает смену хеша в истории, поэтому "назад" и "вперёд" работают.
// Страница при этом НЕ перезагружается: мы ловим событие hashchange и сами
// показываем нужный экран.

let cameFromList = false; // открыли матч кликом из списка (тогда "назад" = history.back)
let listScrollY = 0;      // докуда был пролистан список

// Разбираем адрес: "#/player/123/match/456" -> { page: 'match', accountId: '123', matchId: '456' }
function parseRoute() {
  const parts = location.hash.replace(/^#\/?/, '').split('/').filter(Boolean);
  if (parts[0] === 'player' && /^\d+$/.test(parts[1] || '')) {
    if (parts[2] === 'match' && /^\d+$/.test(parts[3] || '')) {
      return { page: 'match', accountId: parts[1], matchId: parts[3] };
    }
    return { page: 'player', accountId: parts[1] };
  }
  return { page: 'home' };
}

// Показываем экран, который соответствует адресу
async function route() {
  const r = parseRoute();

  if (r.page === 'home') {
    showHome();
    return;
  }

  recentBlock.innerHTML = ''; // "недавние игроки" показываем только на главной

  // Игрок другой (или ещё не загружен) — загружаем
  if (r.accountId !== currentAccountId || matches.length === 0) {
    await loadPlayer(r.accountId);
    if (matches.length === 0) return; // не загрузилось — сообщение уже на экране
  } else if (!playerInfo.hasChildNodes()) {
    renderPlayer(currentProfile, currentAccountId); // вернулись с главной — карточка игрока снова в шапке
  }
  // Пока грузили, адрес мог поменяться ещё раз
  if (location.hash !== `#/player/${r.accountId}${r.page === 'match' ? `/match/${r.matchId}` : ''}`) return;

  if (r.page === 'player') {
    showList();
  } else {
    openMatchById(r.matchId);
  }
}

// ===== Главная страница =====

function showHome() {
  currentMatch = null;
  showScreen('home');
  renderMeta();
  statusText.textContent = '';
  refreshBtn.classList.add('hidden');
  playerInfo.innerHTML = '';
  renderRecentPlayers();

  // Подставляем в поле последний ID (или ID из старой версии сайта)
  if (!accountInput.value) {
    let lastId = getRecentPlayers()[0]?.id;
    try {
      lastId = lastId || localStorage.getItem('accountId') || '';
    } catch {
      // не страшно
    }
    accountInput.value = lastId || '';
  }
  accountInput.focus({ preventScroll: true });
}

// Недавние игроки хранятся в памяти браузера (localStorage):
// [{ id, name, avatar }, ...] — последние 5
function getRecentPlayers() {
  try {
    return JSON.parse(localStorage.getItem('recentPlayers')) || [];
  } catch {
    return [];
  }
}

function saveRecentPlayer(accountId, profile) {
  const entry = {
    id: accountId,
    name: profile?.personaname || `ID ${accountId}`,
    avatar: profile?.avatarmedium || '',
  };
  // Убираем старую запись этого игрока и ставим новую первой
  const list = [entry, ...getRecentPlayers().filter((p) => p.id !== accountId)].slice(0, 5);
  try {
    localStorage.setItem('recentPlayers', JSON.stringify(list));
  } catch {
    // не страшно
  }
}

function renderRecentPlayers() {
  recentBlock.innerHTML = '';
  const list = getRecentPlayers();
  if (!list.length) return;

  const title = document.createElement('p');
  title.className = 'recent-title';
  title.textContent = 'Недавно смотрели';
  recentBlock.appendChild(title);

  const row = document.createElement('div');
  row.className = 'recent-list';
  for (const p of list) {
    // Ссылка, а не кнопка: её можно открыть в новой вкладке
    const link = document.createElement('a');
    link.className = 'recent-player';
    link.href = `#/player/${p.id}`;
    if (p.avatar) {
      const img = document.createElement('img');
      img.src = p.avatar;
      img.alt = '';
      link.appendChild(img);
    }
    const name = document.createElement('span');
    name.textContent = p.name; // textContent — ник безопасно, как текст
    link.appendChild(name);
    row.appendChild(link);
  }
  recentBlock.appendChild(row);
}

// ===================================================
// 11. ПОДКЛЮЧАЕМ КНОПКИ И ЗАПУСКАЕМ
// ===================================================

// submit — отправка формы (по кнопке или по Enter в поле)
searchForm.addEventListener('submit', (event) => {
  event.preventDefault(); // не даём браузеру перезагрузить страницу
  onSearch();
});

// Адрес поменялся (клик, "назад", "вперёд") — показываем нужный экран
window.addEventListener('hashchange', route);

refreshBtn.addEventListener('click', requestRefresh);
moreBtn.addEventListener('click', loadMore);
backBtn.addEventListener('click', goBack);
saveNoteBtn.addEventListener('click', saveNote);
aiBtn.addEventListener('click', analyze);
noteTemplateBtn.addEventListener('click', insertNoteTemplate);

heroFilter.addEventListener('change', () => {
  filters.heroId = heroFilter.value;
  applyFilters();
});

resultFilter.addEventListener('click', (event) => {
  const btn = event.target.closest('button'); // на какую кнопку нажали
  if (!btn || btn.dataset.win === filters.win) return;
  filters.win = btn.dataset.win;
  setResultButtons(filters.win);
  applyFilters();
});

// Запуск при открытии страницы
async function init() {
  await tryCustomHeader();
  try {
    await loadHeroes();
  } catch (error) {
    statusText.textContent = 'Не удалось загрузить список героев: ' + error.message;
    return;
  }

  // Пока матчи не загружены — в шапке случайный герой
  const ids = Object.keys(heroes);
  setHeaderHero(ids[Math.floor(Math.random() * ids.length)]);

  // Показываем экран по текущему адресу (главная, игрок или матч)
  route();
}

init();
