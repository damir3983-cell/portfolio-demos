// ===================================================
// Анимированный фон: Radiant против Dire
//
// Рисуем на <canvas> — это "холст", на котором JavaScript может рисовать
// что угодно пиксель за пикселем. Каждый кадр (около 60 раз в секунду)
// мы стираем холст и рисуем всё заново, чуть сдвинув — так получается анимация.
//
// На холсте:
//  1. Два больших мягких свечения: зелёное (Radiant) слева снизу
//     и красное (Dire) справа сверху. Они медленно "дышат".
//  2. Искры, которые поднимаются вверх, как от костра.
// ===================================================

// (function () { ... })() — "самовызывающаяся функция": все переменные
// внутри неё не пересекаются с переменными из app.js
(function () {
  const canvas = document.getElementById('bg-canvas');
  if (!canvas || !canvas.getContext) return;
  const ctx = canvas.getContext('2d'); // "кисть" для рисования

  const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  let width = 0;
  let height = 0;
  let sparks = [];

  // Цвета искр: в основном золото и огонь, иногда зелёные искры Radiant
  const SPARK_COLORS = ['232, 163, 61', '255, 122, 61', '201, 164, 92', '255, 186, 90', '123, 217, 79'];

  // Случайное число от min до max
  const rand = (min, max) => min + Math.random() * (max - min);

  // Создаёт одну искру. fromBottom = true — появляется внизу экрана
  function makeSpark(fromBottom) {
    return {
      x: rand(0, width),
      y: fromBottom ? height + rand(0, 40) : rand(0, height),
      radius: rand(0.6, 2.2),
      speed: rand(0.15, 0.6),        // скорость подъёма (пикселей за кадр)
      sway: rand(0.2, 1.2),          // насколько раскачивается в стороны
      phase: rand(0, Math.PI * 2),   // сдвиг раскачивания, чтобы искры не двигались одинаково
      alpha: rand(0.25, 0.8),        // прозрачность
      color: SPARK_COLORS[Math.random() < 0.15 ? 4 : Math.floor(rand(0, 4))],
    };
  }

  // Подгоняем холст под размер окна.
  // devicePixelRatio — на чётких экранах (ноутбуки, телефоны) пикселей больше,
  // и без этого рисунок был бы размытым.
  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    width = window.innerWidth;
    height = window.innerHeight;
    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = width + 'px';
    canvas.style.height = height + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    // Количество искр зависит от размера экрана: на телефоне меньше
    const count = Math.round(Math.min(90, (width * height) / 18000));
    sparks = Array.from({ length: count }, () => makeSpark(false));
  }

  // Мягкое круглое свечение (радиальный градиент от цвета к прозрачности)
  function glow(x, y, radius, rgb, alpha) {
    const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius);
    gradient.addColorStop(0, `rgba(${rgb}, ${alpha})`);
    gradient.addColorStop(1, `rgba(${rgb}, 0)`);
    ctx.fillStyle = gradient;
    ctx.fillRect(x - radius, y - radius, radius * 2, radius * 2);
  }

  // Рисует один кадр. time — сколько миллисекунд прошло с загрузки страницы
  function draw(time) {
    ctx.clearRect(0, 0, width, height);

    // Медленное "дыхание": Math.sin даёт плавные колебания от -1 до 1
    const t = time / 1000;
    const size = Math.max(width, height);

    // Radiant — зелёный, слева снизу
    glow(
      width * (0.1 + 0.04 * Math.sin(t * 0.13)),
      height * (0.95 + 0.03 * Math.cos(t * 0.11)),
      size * 0.55,
      '94, 168, 58',
      0.13 + 0.03 * Math.sin(t * 0.4)
    );

    // Dire — красный, справа сверху
    glow(
      width * (0.92 + 0.04 * Math.cos(t * 0.12)),
      height * (0.08 + 0.03 * Math.sin(t * 0.1)),
      size * 0.55,
      '204, 68, 54',
      0.12 + 0.03 * Math.cos(t * 0.37)
    );

    // Искры
    for (const s of sparks) {
      s.y -= s.speed;
      const x = s.x + Math.sin(t * 0.8 + s.phase) * s.sway * 6;
      // Мерцание
      const flicker = 0.6 + 0.4 * Math.sin(t * 3 + s.phase * 2);

      ctx.beginPath();
      ctx.arc(x, s.y, s.radius, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(${s.color}, ${s.alpha * flicker})`;
      ctx.fill();

      // Улетела за верх экрана — появляется заново внизу
      if (s.y < -10) Object.assign(s, makeSpark(true));
    }
  }

  let running = false;

  function loop(time) {
    if (!running) return;
    draw(time);
    // requestAnimationFrame — "нарисуй следующий кадр, когда браузер будет готов".
    // Браузер сам ставит его на паузу в свёрнутой вкладке.
    requestAnimationFrame(loop);
  }

  function start() {
    if (running) return;
    running = true;
    requestAnimationFrame(loop);
  }

  function stop() {
    running = false;
  }

  resize();
  window.addEventListener('resize', resize);

  if (reducedMotion) {
    // Анимации выключены в системе — рисуем один неподвижный кадр
    draw(0);
    window.addEventListener('resize', () => draw(0));
    return;
  }

  // Вкладка скрыта — останавливаем, чтобы не тратить заряд ноутбука
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) stop();
    else start();
  });

  start();
})();
