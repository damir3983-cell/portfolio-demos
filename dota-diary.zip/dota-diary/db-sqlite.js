// ===================================================
// База данных Дневника Доты — вариант SQLite (основной)
// Подключается из database.js, если в Node.js есть модуль node:sqlite (22.5+).
//
// Используем SQLite — база данных, которая хранится в ОДНОМ файле
// (data/diary.db). Её не надо устанавливать и настраивать отдельно:
// модуль node:sqlite уже встроен в Node.js.
//
// Этот файл отвечает ТОЛЬКО за базу. server.js не знает, как именно
// хранятся заметки — он просто вызывает функции отсюда.
// Если потом захотим другую базу (например, PostgreSQL), поменяем только этот файл.
// ===================================================

const { DatabaseSync } = require('node:sqlite');
const fs = require('fs');
const path = require('path');

// Папка data рядом с этим файлом. Если её нет — создаём.
const dataDir = path.join(__dirname, 'data');
fs.mkdirSync(dataDir, { recursive: true });

// Открываем (или создаём, если его ещё нет) файл базы данных
const db = new DatabaseSync(path.join(dataDir, 'diary.db'));

// ===== Создаём таблицу =====

// База данных состоит из таблиц — как листы в Excel.
// Таблица notes: каждая строка — одна заметка.
//
// Колонки:
//   account_id — чья заметка (Dota ID игрока)
//   match_id   — к какому матчу
//   text       — сам текст
//   updated_at — когда последний раз меняли
//
// PRIMARY KEY (account_id, match_id) — у одного игрока к одному матчу
// может быть только ОДНА заметка. Так заметки разных игроков к одному
// матчу больше не смешиваются (в версии с localStorage смешивались).
//
// IF NOT EXISTS — создать, только если таблицы ещё нет.
// Так этот код можно запускать при каждом старте сервера.
db.exec(`
  CREATE TABLE IF NOT EXISTS notes (
    account_id TEXT    NOT NULL,
    match_id   INTEGER NOT NULL,
    text       TEXT    NOT NULL,
    updated_at TEXT    NOT NULL,
    PRIMARY KEY (account_id, match_id)
  )
`);

// Таблица analyses — разборы от ИИ.
// Сохраняем их, чтобы не спрашивать нейросеть заново при каждом открытии матча
// (это экономит токены и время).
db.exec(`
  CREATE TABLE IF NOT EXISTS analyses (
    account_id TEXT    NOT NULL,
    match_id   INTEGER NOT NULL,
    text       TEXT    NOT NULL,
    created_at TEXT    NOT NULL,
    PRIMARY KEY (account_id, match_id)
  )
`);

// ===== Готовим запросы =====

// prepare — "подготовленный запрос". Знаки ? — места для подстановки значений.
//
// ВАЖНО: значения НИКОГДА не вклеиваем прямо в текст SQL, вот так:
//   `SELECT * FROM notes WHERE account_id = '${accountId}'`   ← ОПАСНО!
// Если кто-то пришлёт вместо ID кусок SQL-кода, база его выполнит —
// это называется SQL-инъекция, одна из самых частых уязвимостей сайтов.
// С ? база сама аккуратно подставляет значение как обычные данные.

// Все заметки одного игрока
const selectNotes = db.prepare(
  'SELECT match_id, text FROM notes WHERE account_id = ?'
);

// Сохранить заметку. ON CONFLICT ... DO UPDATE — если заметка к этому матчу
// уже есть, не создаём вторую, а обновляем текст существующей.
const upsertNote = db.prepare(`
  INSERT INTO notes (account_id, match_id, text, updated_at)
  VALUES (?, ?, ?, ?)
  ON CONFLICT (account_id, match_id)
  DO UPDATE SET text = excluded.text, updated_at = excluded.updated_at
`);

// Удалить заметку
const deleteNote = db.prepare(
  'DELETE FROM notes WHERE account_id = ? AND match_id = ?'
);

// Одна заметка (для ИИ-разбора)
const selectOneNote = db.prepare(
  'SELECT text FROM notes WHERE account_id = ? AND match_id = ?'
);

// Разбор ИИ: получить и сохранить (с заменой старого)
const selectAnalysis = db.prepare(
  'SELECT text, created_at FROM analyses WHERE account_id = ? AND match_id = ?'
);
const upsertAnalysis = db.prepare(`
  INSERT INTO analyses (account_id, match_id, text, created_at)
  VALUES (?, ?, ?, ?)
  ON CONFLICT (account_id, match_id)
  DO UPDATE SET text = excluded.text, created_at = excluded.created_at
`);

// ===== Функции, которыми пользуется server.js =====

// Текст одной заметки или пустая строка
function getNote(accountId, matchId) {
  const row = selectOneNote.get(accountId, matchId); // get — получить одну строку (или undefined)
  return row ? row.text : '';
}

// Сохранённый разбор: { text, createdAt } или null
function getAnalysis(accountId, matchId) {
  const row = selectAnalysis.get(accountId, matchId);
  return row ? { text: row.text, createdAt: row.created_at } : null;
}

function saveAnalysis(accountId, matchId, text) {
  const createdAt = new Date().toISOString();
  upsertAnalysis.run(accountId, matchId, text, createdAt);
  return { text, createdAt };
}

// Возвращает все заметки игрока в виде объекта: { номер_матча: "текст", ... }
function getNotes(accountId) {
  const rows = selectNotes.all(accountId); // all — получить все подходящие строки
  const notes = {};
  for (const row of rows) {
    notes[row.match_id] = row.text;
  }
  return notes;
}

// Сохраняет заметку. Пустой текст = удалить заметку.
function saveNote(accountId, matchId, text) {
  if (text.trim() === '') {
    deleteNote.run(accountId, matchId); // run — выполнить запрос, который ничего не возвращает
  } else {
    upsertNote.run(accountId, matchId, text, new Date().toISOString());
  }
}

// module.exports — что этот файл "отдаёт наружу" другим файлам
module.exports = { getNotes, saveNote, getNote, getAnalysis, saveAnalysis };
