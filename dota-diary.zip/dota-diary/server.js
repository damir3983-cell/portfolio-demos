// ===================================================
// Сервер Дневника Доты
// Запуск: в папке проекта выполнить команду  npm start
// Потом открыть в браузере: http://localhost:3000
// На хостинге (Beget) сервер запускает Passenger — см. DEPLOY-BEGET.txt
// ===================================================

// path — встроенный модуль Node.js для работы с путями к файлам
const path = require('path');

// ===== 0. Загружаем настройки из файла .env =====
// Это нужно сделать В САМОМ НАЧАЛЕ — до подключения gigachat.js,
// потому что он читает ключ из process.env сразу при подключении.
// На хостинге сервер запускается не через "npm start", поэтому
// загружаем .env прямо из кода (process.loadEnvFile есть в Node.js 20.12+).
try {
  process.loadEnvFile(path.join(__dirname, '.env'));
} catch {
  // Файла .env нет — не страшно, настройки могут прийти из окружения
}

// require — подключаем библиотеку. express — самый популярный
// инструмент для создания серверов на Node.js.
const express = require('express');

// Наш собственный файл с функциями базы данных.
// ./ значит "в этой же папке".
const db = require('./database');

// ИИ-разбор и проверка, настроен ли GigaChat
const { analyzeMatch } = require('./analyzer');
const gigachat = require('./gigachat');
const { getItemsLite } = require('./opendota');

// Создаём сервер (в Express его принято называть app — "приложение")
const app = express();

// Порт — "номер двери", через которую браузер стучится к серверу.
// localhost:3000 = "этот компьютер, дверь номер 3000".
// На хостинге порт выдаёт сам хостинг через переменную окружения PORT.
const PORT = process.env.PORT || 3000;

// На хостинге перед нашим сервером стоят другие серверы (Nginx, Apache),
// и настоящий адрес посетителя они передают в заголовке X-Forwarded-For.
// Эта настройка говорит Express брать адрес оттуда (нужно для лимитов ниже).
app.set('trust proxy', true);

// ===== 1. Настройки =====

// express.json — учит сервер понимать данные в формате JSON,
// которые присылает браузер (например, текст заметки).
// Без этой строки req.body будет пустым.
// limit: '20kb' — не принимаем слишком большие запросы.
app.use(express.json({ limit: '20kb' }));

// express.static — отдаёт файлы из папки public как есть.
// Браузер просит /style.css — сервер отдаёт public/style.css.
// Браузер просит / — сервер отдаёт public/index.html.
//
// ВАЖНО: раздаём ТОЛЬКО папку public. Всё, что лежит вне её
// (server.js, база данных, а потом файл .env с секретным ключом от ИИ),
// браузер получить не сможет.
//
// __dirname — путь к папке, где лежит этот файл (server.js)
app.use(express.static(path.join(__dirname, 'public')));

// ===== 2. Проверка данных =====

// Проверяем, что строка состоит только из цифр (и не слишком длинная).
// Никогда не доверяй тому, что прислал браузер: любой может отправить
// на сервер что угодно в обход нашей страницы.
function isDigits(value) {
  return typeof value === 'string' && /^\d{1,20}$/.test(value);
}

// ===== 3. API =====

// API — это адреса, которые возвращают не страницу, а данные (в формате JSON).
// app.get('/адрес', функция) — "когда браузер запросит этот адрес, выполни функцию".
//   req (request)  — запрос: что прислал браузер
//   res (response) — ответ: что мы отправим обратно

// Проверка "сервер жив?"
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    message: 'Сервер Дневника Доты работает!',
    time: new Date().toLocaleString('ru-RU'),
  });
});

// Получить все заметки игрока.
// :accountId — "параметр": часть адреса, которая меняется.
// Запрос /api/notes/843808443 — и в req.params.accountId окажется "843808443".
app.get('/api/notes/:accountId', (req, res) => {
  const { accountId } = req.params;

  if (!isDigits(accountId)) {
    // 400 — код ответа "плохой запрос" (ошибка того, кто прислал)
    return res.status(400).json({ error: 'Неверный ID игрока' });
  }

  const notes = db.getNotes(accountId);
  res.json(notes);
});

// Сохранить заметку к матчу.
// PUT — тип запроса "положи/замени данные по этому адресу".
// (GET — получить, POST — создать, PUT — заменить, DELETE — удалить.)
app.put('/api/notes/:accountId/:matchId', (req, res) => {
  const { accountId, matchId } = req.params;
  const text = req.body?.text;

  if (!isDigits(accountId) || !isDigits(matchId)) {
    return res.status(400).json({ error: 'Неверный ID игрока или матча' });
  }
  if (typeof text !== 'string' || text.length > 5000) {
    return res.status(400).json({ error: 'Текст заметки должен быть строкой до 5000 символов' });
  }

  db.saveNote(accountId, Number(matchId), text);
  res.json({ ok: true });
});

// Справочник предметов (названия и картинки) для страницы матча
app.get('/api/items', async (req, res) => {
  try {
    const items = await getItemsLite();
    // Cache-Control — разрешаем браузеру запомнить ответ на час,
    // чтобы не скачивать справочник при каждом открытии матча
    res.set('Cache-Control', 'public, max-age=3600');
    res.json(items);
  } catch (error) {
    res.status(502).json({ error: error.message });
  }
});

// Получить сохранённый разбор матча (если его уже делали)
app.get('/api/analysis/:accountId/:matchId', (req, res) => {
  const { accountId, matchId } = req.params;
  if (!isDigits(accountId) || !isDigits(matchId)) {
    return res.status(400).json({ error: 'Неверный ID игрока или матча' });
  }
  res.json({ analysis: db.getAnalysis(accountId, Number(matchId)) });
});

// Сюда запоминаем разборы, которые прямо сейчас в процессе,
// чтобы двойной клик по кнопке не отправил два запроса в GigaChat.
// Set — набор уникальных значений.
const inProgress = new Set();

// ===== Лимиты на разборы ИИ =====
// Когда сайт в интернете, кнопку "Разобрать" может жать кто угодно —
// и каждый разбор тратит токены GigaChat с ТВОЕГО ключа.
// Поэтому ограничиваем: сколько разборов в час с одного адреса
// и сколько всего в сутки на весь сайт. Числа можно поменять в .env.
const AI_PER_IP_HOUR = Number(process.env.AI_PER_IP_HOUR) || 10;
const AI_PER_DAY = Number(process.env.AI_PER_DAY) || 100;

const ipHits = new Map(); // адрес посетителя -> время его последних разборов
let dayKey = '';          // какой сегодня день ("2026-10-16")
let dayCount = 0;         // сколько разборов сделано сегодня

// Возвращает "попытку" обратно, если разбор не удался (ошибка OpenDota или GigaChat)
function refundAiLimit(ip) {
  const times = ipHits.get(ip);
  if (times && times.length) times.pop();
  if (dayCount > 0) dayCount--;
}

// Возвращает текст ошибки, если лимит превышен, или null, если можно
function checkAiLimit(ip) {
  const now = Date.now();
  const HOUR = 60 * 60 * 1000;

  // Новый день — обнуляем дневной счётчик
  const today = new Date().toISOString().slice(0, 10);
  if (today !== dayKey) {
    dayKey = today;
    dayCount = 0;
  }
  if (dayCount >= AI_PER_DAY) {
    return 'На сегодня лимит разборов на сайте исчерпан. Попробуй завтра.';
  }

  // Оставляем только разборы за последний час
  const recent = (ipHits.get(ip) || []).filter((t) => now - t < HOUR);
  if (recent.length >= AI_PER_IP_HOUR) {
    const minutes = Math.ceil((HOUR - (now - recent[0])) / 60000);
    return `Слишком много разборов подряд. Следующий можно через ${minutes} мин.`;
  }

  recent.push(now);
  ipHits.set(ip, recent);
  dayCount++;

  // Чистим память от старых записей, чтобы список не рос бесконечно
  if (ipHits.size > 1000) {
    for (const [key, times] of ipHits) {
      if (times.every((t) => now - t >= HOUR)) ipHits.delete(key);
    }
  }
  return null;
}

// Сделать новый разбор матча через ИИ.
// POST — тип запроса "создай что-то новое".
// async — потому что внутри мы ждём ответа от OpenDota и GigaChat.
app.post('/api/analysis/:accountId/:matchId', async (req, res) => {
  const { accountId, matchId } = req.params;
  if (!isDigits(accountId) || !isDigits(matchId)) {
    return res.status(400).json({ error: 'Неверный ID игрока или матча' });
  }
  if (!gigachat.isConfigured()) {
    // 503 — "сервис недоступен"
    return res.status(503).json({ error: 'ИИ не настроен: впиши ключ GIGACHAT_AUTH_KEY в файл .env и перезапусти сервер' });
  }

  const key = `${accountId}:${matchId}`;
  if (inProgress.has(key)) {
    // 409 — "конфликт": такой запрос уже выполняется
    return res.status(409).json({ error: 'Разбор этого матча уже готовится, подожди' });
  }

  // 429 — код ответа "слишком много запросов"
  const limitError = checkAiLimit(req.ip);
  if (limitError) {
    return res.status(429).json({ error: limitError });
  }

  inProgress.add(key);
  try {
    // Берём заметку игрока из базы — она поможет ИИ понять контекст
    const note = db.getNote(accountId, Number(matchId));
    const text = await analyzeMatch(matchId, accountId, note);
    const analysis = db.saveAnalysis(accountId, Number(matchId), text);
    res.json({ analysis });
  } catch (error) {
    // Пишем подробности в терминал (для нас), а браузеру — понятное сообщение
    console.error('Ошибка разбора матча', matchId, ':', error.message);
    // Разбор не получился — не засчитываем его в лимиты
    refundAiLimit(req.ip);
    // 502 — "ошибка внешнего сервиса" (OpenDota или GigaChat)
    res.status(502).json({ error: error.message });
  } finally {
    // finally выполняется всегда — и при успехе, и при ошибке
    inProgress.delete(key);
  }
});

// ===== 4. Запускаем сервер =====

// listen — сервер начинает "слушать" порт и ждать запросов.
// Функция внутри выполнится один раз, когда сервер запустится.
app.listen(PORT, () => {
  console.log('==========================================');
  console.log(' Сервер запущен!');
  console.log(` Открой в браузере: http://localhost:${PORT}`);
  console.log(' Остановить сервер: Ctrl+C');
  console.log(
    gigachat.isConfigured()
      ? ` ИИ: GigaChat подключён (модель ${gigachat.MODEL})`
      : ' ИИ: НЕ подключён — впиши ключ в файл .env'
  );
  console.log('==========================================');
});
