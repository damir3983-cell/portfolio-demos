// ===================================================
// База данных Дневника Доты — запасной вариант: JSON-файл
// Подключается из database.js, если в Node.js нет модуля node:sqlite.
//
// Все данные держим в памяти в одном объекте, а после каждого изменения
// записываем его в файл data/diary.json. При запуске сервера читаем файл.
// ===================================================

const fs = require('fs');
const path = require('path');

const dataDir = path.join(__dirname, 'data');
const file = path.join(dataDir, 'diary.json');
fs.mkdirSync(dataDir, { recursive: true });

// Структура: { notes: { "игрок:матч": {...} }, analyses: { "игрок:матч": {...} } }
let data = { notes: {}, analyses: {} };
try {
  data = { ...data, ...JSON.parse(fs.readFileSync(file, 'utf8')) };
} catch {
  // Файла ещё нет (первый запуск) — начинаем с пустой базы
}

// Записываем безопасно: сначала во временный файл, потом подменяем.
// Если сервер упадёт посреди записи, старый файл останется целым.
function save() {
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data));
  fs.renameSync(tmp, file);
}

const key = (accountId, matchId) => `${accountId}:${matchId}`;

function getNotes(accountId) {
  const notes = {};
  const prefix = `${accountId}:`;
  for (const [k, note] of Object.entries(data.notes)) {
    if (k.startsWith(prefix)) notes[k.slice(prefix.length)] = note.text;
  }
  return notes;
}

function saveNote(accountId, matchId, text) {
  if (text.trim() === '') {
    delete data.notes[key(accountId, matchId)];
  } else {
    data.notes[key(accountId, matchId)] = { text, updatedAt: new Date().toISOString() };
  }
  save();
}

function getNote(accountId, matchId) {
  return data.notes[key(accountId, matchId)]?.text || '';
}

function getAnalysis(accountId, matchId) {
  const a = data.analyses[key(accountId, matchId)];
  return a ? { text: a.text, createdAt: a.createdAt } : null;
}

function saveAnalysis(accountId, matchId, text) {
  const createdAt = new Date().toISOString();
  data.analyses[key(accountId, matchId)] = { text, createdAt };
  save();
  return { text, createdAt };
}

module.exports = { getNotes, saveNote, getNote, getAnalysis, saveAnalysis };
