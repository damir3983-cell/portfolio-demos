// ===================================================
// Работа с нейросетью GigaChat (Сбер)
//
// Как это устроено:
//  1. У нас есть КЛЮЧ АВТОРИЗАЦИИ (лежит в файле .env, не в коде!).
//  2. Ключом нельзя сразу задавать вопросы. Сначала меняем его на
//     ТОКЕН ДОСТУПА — временный пропуск, который живёт 30 минут.
//  3. С токеном отправляем вопрос в GigaChat и получаем ответ.
//
// Токен мы запоминаем и используем повторно, пока он не истёк,
// чтобы не просить новый на каждый вопрос.
//
// Весь код про GigaChat — только в этом файле. Если захотим другую
// нейросеть, поменяем этот файл, а остальной сайт ничего не заметит.
// ===================================================

const https = require('https');
const http = require('http');
const tls = require('tls');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// ===== Настройки (берутся из файла .env) =====

// process.env — это "переменные окружения": настройки, которые передаются
// программе снаружи. Файл .env подгружается при запуске (см. package.json).
const AUTH_KEY = (process.env.GIGACHAT_AUTH_KEY || '').replace(/^Basic\s+/i, '').trim();
const SCOPE = process.env.GIGACHAT_SCOPE || 'GIGACHAT_API_PERS'; // PERS = для физлиц
const MODEL = process.env.GIGACHAT_MODEL || 'GigaChat-2-Pro';
const OAUTH_URL = process.env.GIGACHAT_OAUTH_URL || 'https://ngw.devices.sberbank.ru:9443/api/v2/oauth';
const API_URL = process.env.GIGACHAT_API_URL || 'https://api.giga.chat/v1';

// ===== Сертификат НУЦ Минцифры =====

// Сервера Сбера используют российский сертификат безопасности.
// Node.js его не знает и по умолчанию откажется соединяться
// (ошибка вроде "self-signed certificate in certificate chain").
// Поэтому мы держим файл сертификата в папке certs и добавляем его
// к списку доверенных — ТОЛЬКО для запросов к GigaChat, не для всего сервера.
const CERT_PATH = path.join(__dirname, 'certs', 'russian_trusted_root_ca.pem');
const CERT_URL = 'https://gu-st.ru/content/lending/russian_trusted_root_ca_pem.crt';

let trustedCAs = null; // список доверенных сертификатов (заполним при первом запросе)

async function loadCertificates() {
  if (trustedCAs) return trustedCAs;

  // Если файла нет — пробуем скачать его с официального сайта Госуслуг
  if (!fs.existsSync(CERT_PATH)) {
    console.log('Сертификат Минцифры не найден, скачиваю...');
    try {
      const response = await fetch(CERT_URL);
      if (!response.ok) throw new Error('ошибка ' + response.status);
      const pem = await response.text();
      if (!pem.includes('BEGIN CERTIFICATE')) throw new Error('скачался не сертификат');
      fs.mkdirSync(path.dirname(CERT_PATH), { recursive: true });
      fs.writeFileSync(CERT_PATH, pem);
      console.log('Сертификат сохранён в папку certs');
    } catch (error) {
      console.log('Не удалось скачать сертификат: ' + error.message);
      console.log(`Скачай его вручную: ${CERT_URL}`);
      console.log(`и сохрани как: ${CERT_PATH}`);
    }
  }

  // tls.rootCertificates — стандартные сертификаты, которые Node.js знает сам.
  // Добавляем к ним российский (если он есть).
  trustedCAs = [...tls.rootCertificates];
  if (fs.existsSync(CERT_PATH)) {
    trustedCAs.push(fs.readFileSync(CERT_PATH, 'utf8'));
  }
  return trustedCAs;
}

// ===== Отправка запроса =====

// Встроенный fetch не умеет добавлять свои сертификаты, поэтому для GigaChat
// используем модуль https напрямую. Эта функция отправляет запрос
// и возвращает ответ, уже превращённый из JSON в объект.
async function request(url, { method = 'POST', headers = {}, body = '' } = {}) {
  const ca = await loadCertificates();
  const target = new URL(url);
  const lib = target.protocol === 'http:' ? http : https; // http — только для тестов

  // new Promise — "обещание вернуть результат позже".
  // resolve(значение) — всё хорошо, reject(ошибка) — что-то сломалось.
  return new Promise((resolve, reject) => {
    const req = lib.request(
      target,
      {
        method,
        headers: { ...headers, 'Content-Length': Buffer.byteLength(body) },
        ca,
        timeout: 60000, // ждём ответ не дольше 60 секунд
      },
      (res) => {
        // Ответ приходит кусками — собираем их в одну строку
        let data = '';
        res.setEncoding('utf8');
        res.on('data', (chunk) => (data += chunk));
        res.on('end', () => {
          let json = null;
          try {
            json = JSON.parse(data);
          } catch {
            // ответ не JSON — оставим json = null
          }
          if (res.statusCode >= 400) {
            const details = json?.message || json?.error_description || data.slice(0, 200);
            return reject(new Error(`GigaChat ответил ошибкой ${res.statusCode}: ${details}`));
          }
          resolve(json);
        });
      }
    );

    req.on('timeout', () => req.destroy(new Error('GigaChat слишком долго не отвечает')));
    req.on('error', (error) => {
      // Подсказка для самой частой проблемы
      if (/certificate/i.test(error.message)) {
        error.message +=
          ' — проблема с сертификатом Минцифры. Проверь, что файл certs/russian_trusted_root_ca.pem на месте.';
      }
      reject(error);
    });

    req.write(body);
    req.end();
  });
}

// ===== Токен доступа =====

let token = null;        // сам токен
let tokenExpiresAt = 0;  // когда он истечёт (в миллисекундах)

async function getToken() {
  // Если токен есть и до его окончания больше минуты — используем его
  if (token && Date.now() < tokenExpiresAt - 60_000) {
    return token;
  }

  if (!AUTH_KEY) {
    throw new Error('Не задан ключ GIGACHAT_AUTH_KEY в файле .env');
  }

  const data = await request(OAUTH_URL, {
    headers: {
      Authorization: `Basic ${AUTH_KEY}`,
      RqUID: crypto.randomUUID(), // уникальный номер запроса, Сбер требует его
      'Content-Type': 'application/x-www-form-urlencoded',
      Accept: 'application/json',
    },
    body: `scope=${SCOPE}`,
  });

  token = data.access_token;
  // expires_at может прийти в секундах или миллисекундах — приводим к миллисекундам
  const exp = Number(data.expires_at) || 0;
  tokenExpiresAt = exp > 1e12 ? exp : exp * 1000;
  if (!tokenExpiresAt) tokenExpiresAt = Date.now() + 25 * 60_000; // на всякий случай

  return token;
}

// ===== Главная функция: задать вопрос =====

// messages — список сообщений в формате:
//   [{ role: 'system', content: 'кто ты и как отвечать' },
//    { role: 'user',   content: 'сам вопрос' }]
// Возвращает текст ответа.
async function ask(messages) {
  const accessToken = await getToken();

  const data = await request(`${API_URL}/chat/completions`, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
    body: JSON.stringify({
      model: MODEL,
      messages,
      // 0.1 — сухо и предсказуемо, 1+ — "творчески". При слишком высокой
      // температуре ИИ начинает фантазировать (и коверкать названия предметов).
      temperature: 0.7,
      max_tokens: 1500, // ограничение длины ответа
    }),
  });

  const text = data?.choices?.[0]?.message?.content;
  if (!text) throw new Error('GigaChat вернул пустой ответ');
  return text;
}

// Есть ли вообще ключ (чтобы сайт мог показать понятную ошибку)
function isConfigured() {
  return Boolean(AUTH_KEY);
}

module.exports = { ask, isConfigured, MODEL };
